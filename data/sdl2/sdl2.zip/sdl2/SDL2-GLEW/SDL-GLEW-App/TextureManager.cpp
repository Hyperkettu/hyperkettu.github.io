//
//  TextureManager.cpp
//  SDL-GLEW-App
//
//  Created by Olli Kettunen on 2/6/17.
//  Copyright © 2017 Olli Kettunen. All rights reserved.
//

#include "TextureManager.h"

namespace Fox {

TextureManager* TextureManager::m_Singleton = nullptr;

}
