﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Diagnostics;
using System;
using System.IO;

/**
	This class represents the User Interface handler that is used to select a league and a team for analyzation
*/
public class UIHandler : MonoBehaviour {

    public Dropdown leagueDropDown; // drop down menu for leagues
    public Dropdown teamDropDown; // drop down menu for teams
    public Text leagueNameText; // text league name
    public Image leagueImage; // league image

    public Text teamName; // team name
    public Image teamImage; // image for team

    public Image downloadLabel;

    public Sprite[] loads;

    //public Text test;
    public RectTransform betField;

    public RectTransform panel;

    // prefabs for leagues
    public LaLigaLeague laLigaPrefab;
    public PremierLeague premierLeaguePrefab;
    public Bundesliga bundesPrefab;
    public Ligue1Liga ligue1Prefab;
    public SerieALiga serieAPrefab;
    public NHL NHLPrefab;

   // public TextAsset[] csvFiles; // CSV files of season data

    private Dictionary<string, int> nameToLeagueIndex = new Dictionary<string, int>();

    public List<League> leagues = new List<League>();

    public League currentLeague; // current league
    public Team currentTeam; // current team

    private List<SportsEvent> gamesForCurrentTeam; // games for current team

    private List<GameObject> gameInfosToDestroy = new List<GameObject>();

   // private string urlText = "";
    private Process process;

    private int counter = 0;

    private bool downloadReady = false;

	// Use this for initialization
	void Start () {
        InitLeagues();
        SelectLeague();

        // match data is located on the url below
        string url = "https://dl.dropboxusercontent.com/u/59215222/kettunen/data/matchdata.txt";
        DownloadFileFromURL(url);
	}

	/**
	 *	Downloads a file from the url given as a parameter
	 *  @param url Url to retrieve from
	 */
    public void DownloadFileFromURL(string url)
    {

        StartCoroutine("StartDownload");

        StartCoroutine(HandleWWWRequest(url, (www) =>
        {
            HandleLeagueData(www.text);

        }));

    }

	/**
	 * Callback to handle the league data from parameter data
	 * 
	 * @param urlText Data to be parsed to teams
     */
    public void HandleLeagueData(string urlText) {
        FillLeaguesWithData(urlText);

        // sort all teams alphabetically and matches syncronously in all leagues
        for (int i = 0; i < leagues.Count; i++)
        {
            leagues[i].SortTeamsAlphabetically();
            leagues[i].SortMatchesSyncronously();
            leagues[i].AddLogosToTeams();
        }
    }

	/**
	 * Asyncronous method to handle www request
	 * 
	 * @param url 
	 * @param callback to call on success
	 **/
	
    IEnumerator HandleWWWRequest(string url, System.Action<WWW> onSuccess)
    {
        WWW www = new WWW(url);
        yield return www;

        if (string.IsNullOrEmpty(www.error))
        {
            onSuccess(www);
        }
    }

	/**
	 * This method starts the analyze window for a selected team
	 *
	 * @param index Index of the team in the archived data list
	 */
    public void StartAnalyze(int index) {

        int i = index;

        AnalyzeSet.games.Clear();

        while (i < gamesForCurrentTeam.Count) {
            SportsEvent se = gamesForCurrentTeam[i];
            AnalyzeSet.games.Add(se);

            if (AnalyzeSet.games.Count >= CoordinteSystem.numGames) {
                break;
            }

            i++;
        }

        AnalyzeSet.games.Sort(delegate(SportsEvent e1, SportsEvent e2)
        {
            return e1.date.CompareTo(e2.date);
        });

        AnalyzeSet.currentTeam = currentTeam.name;

        SceneManager.LoadScene("Scenes/analyzer");
        
    }

    /**
     * This function selects a leagues as current based on drop down menu
     * */
    public void SelectLeague() {
        currentLeague = leagues[leagueDropDown.value];
        leagueNameText.text = currentLeague.leagueName;
        leagueImage.sprite = currentLeague.leagueLogo;

        // collect teams
        List<string> teams = new List<string>();
        for (int i = 0; i < currentLeague.teams.Count; i++) {
            teams.Add(currentLeague.teams[i].name);
        }
        // add them as a option to drop down menu
        teamDropDown.ClearOptions();
        teamDropDown.value = 0;
        teamDropDown.AddOptions(teams);
    }

    /**
     * This function selects a team from current league from dropdown menu. Loads all game events for selected team
     * */
    public void SelectTeam() {

        // if there are any team infos destroy
        if (gameInfosToDestroy.Count > 0) {
            for (int i = 0; i < gameInfosToDestroy.Count; i++) {
                Destroy(gameInfosToDestroy[i]);
            }
            gameInfosToDestroy.Clear();
        }

        if (currentLeague) {
            currentTeam = currentLeague.teams[teamDropDown.value];
            teamName.text = currentTeam.name;
            teamImage.sprite = currentTeam.logo;

            gamesForCurrentTeam = currentLeague.GetMatchesFor(currentTeam.name);

            float initialHeight = panel.rect.height;

            float h = -30 - gamesForCurrentTeam.Count * 30;
            panel.offsetMin = new Vector2(panel.offsetMin.x, h);

            float xOffset = 0; // could be 50 or more
            float height = panel.rect.height;

            for (int i = 0; i < gamesForCurrentTeam.Count; i++)
            {

                RectTransform bf = (RectTransform)Instantiate(betField);
                bf.SetParent(panel.transform);
                bf.localPosition = new Vector3(xOffset, (height / 2.0f - 30) - 30 * i, bf.localPosition.z);
                SportsEvent sportsEvent = gamesForCurrentTeam[i];
                FillBetField(bf, sportsEvent);

                Button b = bf.GetComponentInChildren<Button>();
               
                int tempInt = i;
                b.onClick.AddListener(() => StartAnalyze(tempInt));

                gameInfosToDestroy.Add(bf.gameObject);
            }

            

        }
    }

    /**
     * Fills screen with info from sports event
     * 
     * @param UI element to be filled
     * @param sport event where the data comes from
     * */
    public void FillBetField(RectTransform field, SportsEvent sportsEvent) {

        Transform homeOdd = field.FindChild("HomeOdd");
        Transform drawOdd = field.FindChild("DrawOdd");
        Transform awayOdd = field.FindChild("AwayOdd");

        Text info = field.FindChild("MatchInfo").GetComponent<Text>();
        info.text = sportsEvent.GetMatchTeams();

        Text goals = field.FindChild("Goals").GetComponent<Text>();
        goals.text = sportsEvent.GetResult();

        Text date = field.FindChild("Date").GetComponent<Text>();
        date.text = sportsEvent.GetDate();

        if (sportsEvent.result == "1") { // result is home win

            Color color;
            
            // it is a victory 
            if (currentTeam.name == sportsEvent.homeTeamName)
            {
                color = Color.green;
            }
            else {
                color = Color.red; // it is a defeat
            }
            homeOdd.GetComponent<CanvasRenderer>().SetColor(color);
            homeOdd.GetComponentInChildren<Text>().color = Color.white;

        }
        else if (sportsEvent.result == "X") // result is tie
        {
            drawOdd.GetComponent<CanvasRenderer>().SetColor(Color.red); // red color due to fail
            drawOdd.GetComponentInChildren<Text>().color = Color.white;
        }
        else { // result is 2, ie away win

            Color color;

            // it is a victory 
            if (currentTeam.name == sportsEvent.awayTeamName)
            {
                
                color = Color.green;
            }
            else
            {
                color = Color.red; // it is a defeat
            }

            awayOdd.GetComponent<CanvasRenderer>().SetColor(color);
            awayOdd.GetComponentInChildren<Text>().color = Color.white;
        }

        homeOdd.GetComponentInChildren<Text>().text = "" + sportsEvent.homeWinOdd;
        drawOdd.GetComponentInChildren<Text>().text = "" + sportsEvent.drawOdd;
        awayOdd.GetComponentInChildren<Text>().text = "" + sportsEvent.awayWinOdd;
    
    }

    /**
     * Instantiates league prefabs 
     * */
    public void InitLeagues() {

        // La Liga
        nameToLeagueIndex.Add("SP1", 0);
        League laLiga = Instantiate(laLigaPrefab) as League;
        leagues.Add(laLiga);

        // premier league
        nameToLeagueIndex.Add("E0", 1);
        League premier = Instantiate(premierLeaguePrefab) as League;
        leagues.Add(premier);

        // bundesliga
        nameToLeagueIndex.Add("D1", 2);
        League bundes = Instantiate(bundesPrefab) as League;
        leagues.Add(bundes);

        // ligue 1
        nameToLeagueIndex.Add("F1", 3);
        League ligue1 = Instantiate(ligue1Prefab) as League;
        leagues.Add(ligue1);

        // Serie A
        nameToLeagueIndex.Add("I1", 4);
        League serieA = Instantiate(serieAPrefab) as League;
        leagues.Add(serieA);

        // NHL
        nameToLeagueIndex.Add("NHL", 5);
        League nhl = Instantiate(NHLPrefab) as League;
        leagues.Add(nhl);

        List<string> leagueOptions = new List<string>();

        // add league options to drop down menu
        for (int i = 0; i < leagues.Count; i++) {
            leagueOptions.Add(leagues[i].leagueName);
        }

        leagueDropDown.AddOptions(leagueOptions);
    }

    /**
     * Fills all the leagues with match data
     * */
    public void FillLeaguesWithData(string urlText) {

        List<string> teamNames = new List<string>();

        string[] lines = urlText.Split("\n"[0]);

        for (int i = 0; i < lines.Length; i++) {

            if (lines[i].Length == 0)
                continue;

            SportsEvent se = CSVReader.GetSportsEvent(lines[i]);
            leagues[nameToLeagueIndex[se.leagueName]].AddMatch(se);
        }

            // add teams from match data

        for (int i = 0; i < leagues.Count; i++) {
            leagues[i].AddTeamsFromMatchData();
        }

        downloadReady = true;
         
    }

	/**
	 * Shows loading label while downloading the data from url
	 **/
    IEnumerator StartDownload() {

        downloadLabel.gameObject.SetActive(true);

        int i = 0;

        while (!downloadReady)
        {
            yield return new WaitForSeconds(0.15f);
            downloadLabel.sprite = loads[i];

            i = (i + 1) % 3;
        }

        downloadLabel.sprite = loads[3];
        yield return new WaitForSeconds(1.5f);
        Destroy(downloadLabel.gameObject);
    }


}
