﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections.Generic;

/**
 * This class represents the coordinate system where the graph of the analyzed match data is rendered
 */
public class CoordinteSystem : MonoBehaviour {

    public GameObject capsule;
    public GameObject betInfoPrefab;
    public Camera camera;
    public float cameraSpeed = 0.5f;
    public float perspectiveZoomSpeed = 0.5f;
    public GameObject panel;
    public Dropdown resDropDown;

    public InputField betField;
    public Text currentBetText;

    private List<GameObject> xAxisObjects = new List<GameObject>();

    private float unitWidth = 1.0f;
    private float unitHeight = 0.5f;

    public static int numGames = 32;

    public int playIndex;

    public List<BetInfo> betInfos = new List<BetInfo>();

    public float currentBet;

    public int winCondition = 0; // 0 means win, 1 means tie, 2 means loss

    public Button[] stateButtons;

    public Text needMoneyLabel;

	// Use this for initialization
	void Start () {

        playIndex = 0;
        currentBet = 0.0f;
        currentBetText.text = "" + currentBet;

        SetWinCondition(0);
        XAxis(unitWidth * numGames);
        YAxis(unitHeight * 200.0f);

        
	}

	
	// Update is called once per frame
	void Update () {


        // camera panning
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Moved)
        {
            Vector2 touchDeltaPosition = Input.GetTouch(0).deltaPosition;
            camera.transform.Translate(-touchDeltaPosition.x * cameraSpeed, -touchDeltaPosition.y * cameraSpeed, 0);
        }

        // camera zooming
        if (Input.touchCount == 2)
        {
            // Store both touches.
            Touch touchZero = Input.GetTouch(0);
            Touch touchOne = Input.GetTouch(1);

            // Find the position in the previous frame of each touch.
            Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
            Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

            // Find the magnitude of the vector (the distance) between the touches in each frame.
            float prevTouchDeltaMag = (touchZeroPrevPos - touchOnePrevPos).magnitude;
            float touchDeltaMag = (touchZero.position - touchOne.position).magnitude;

            // Find the difference in the distances between each frame.
            float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;

            
            // Otherwise change the field of view based on the change in distance between the touches.
            camera.fieldOfView += deltaMagnitudeDiff * perspectiveZoomSpeed;

            // Clamp the field of view to make sure it's between 0 and 180.
            camera.fieldOfView = Mathf.Clamp(camera.fieldOfView, 0.1f, 179.9f);
            
        }

        if (Input.GetMouseButtonDown(0) || Input.touchCount > 0)
        {

            if (panel.activeSelf) {
                HideData();
            }

            Ray ray = camera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.transform.gameObject.tag == "BetInfo")
                {
                    BetInfo bi = hit.transform.gameObject.GetComponent<BetInfo>();

                    if (!bi.showData)
                    {
                        ShowData(bi);
                    }
                    else {
                        HideData();
                    }

                    bi.showData = !bi.showData;
                }
            }
        }

        if (Input.GetKeyDown(KeyCode.L)) {
            LinearBet();

        }
        if (Input.GetKeyDown(KeyCode.C)) {
            ConstantBet();
        }

        if (Input.GetKeyDown(KeyCode.K))
        {
            SteepLinearBet(7);
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            ExponentialBet();
        }
	}

	/**
	 * Fills the drop down menu that shows show most we have won or lost money in all of the points in the graph 
	 */
    public void FillDropDown() {

        resDropDown.ClearOptions();

        float needMoney = 0;
        float nextBet = 0;

        List<string> betData = new List<string>();

        for (int i = 0; i < betInfos.Count; i++)
        {
            betData.Add("" + betInfos[i].index + ": Bet: " + betInfos[i].currentBetAmount + ", total win: " + betInfos[i].totalAmount);

            if (betInfos[i].totalAmount <= needMoney) {
                needMoney = betInfos[i].totalAmount;
                nextBet = betInfos[i + 1].currentBetAmount;
                
            }

            
        }

        resDropDown.AddOptions(betData);

        needMoneyLabel.text = "Need Money: " + (-needMoney + nextBet);
    }

	/*/ 
	 * Sets the condition whether we analyze only, wins, ties or losses for the current team
	 */
    public void SetWinCondition(int condition) {
        this.winCondition = condition;
        
        for(int i = 0; i < stateButtons.Length; i++){
            if (i != condition)
            {
                stateButtons[i].GetComponent<Image>().color = Color.white;
                stateButtons[i].GetComponentInChildren<Text>().color = Color.black;
                
            }
            else {
                stateButtons[i].GetComponent<Image>().color = Color.green;
                stateButtons[i].GetComponentInChildren<Text>().color = Color.white;
            }
        }

    }

	/**
	 * Clear the graph data to draw a new graph for another strategy
	 */
    public void ClearPreviuosData() {


        if (betInfos.Count > 0) {

            for (int i = 0; i < betInfos.Count; i++) {
                Destroy(betInfos[i].gameObject);
            }

            betInfos.Clear();
            playIndex = 0;
        
        }

        resDropDown.ClearOptions();
    }

	/**
	 * Betting strategy where we always double the be while we continue losing, and start again from 1 if last bet was a victory
	 */
    public void ExponentialBet()
    {

        ClearPreviuosData();

        int i = 0;

        currentBet = 1.0f;
        float initialBet = currentBet;

        while (i <= numGames)
        {

            Bet();

            if (betInfos.Count > 0)
            {

                float result = betInfos[betInfos.Count - 1].result;

                if (result < 0)
                {
                    currentBet *= 2.0f;
                }
                else
                {
                    currentBet = initialBet;
                }

            }


            i++;

        }

        FillDropDown();

    }

	/**
	 * A betting strategy where we linearly increase the bet while we lose, if lost numLosses times we compensate the losses with a steeper linear increase until we win and start from 1 then
	 */
    public void SteepLinearBet(int numLosses)
    {

        ClearPreviuosData();

        int i = 0;

        currentBet = 1.0f;
        float initialBet = currentBet;

        int losses = 0;

        while (i <= numGames)
        {

            Bet();

            if (betInfos.Count > 0)
            {

                float result = betInfos[betInfos.Count - 1].result;

                if (result < 0)
                {
                    currentBet += initialBet;
                    losses++;

                    if (losses >= numLosses) {
                        currentBet += (numLosses-1) * initialBet;
                    }
                }
                else
                {
                    currentBet = initialBet;
                    losses = 0;
                }

            }


            i++;

        }
        FillDropDown();
    }
	
	/**
	 * A betting strategy where we linearly increase the bet while we lose until we win and start from 1 again
	 */
    public void LinearBet(){

        ClearPreviuosData();

        int i = 0;

        currentBet = 1.0f;
        float initialBet = currentBet;

        while(i <= numGames){

            Bet();

            if (betInfos.Count > 0)
            {

                float result = betInfos[betInfos.Count - 1].result;

                if (result < 0)
                {
                    currentBet += initialBet;
                }
                else {
                    currentBet = initialBet;
                }

            }


            i++;
        
        }
        FillDropDown();
    }

	/**
	 * A betting strategy where we always be the same bet regardless whether we lost or won the previous bet
	 */
    public void ConstantBet() {

        ClearPreviuosData();

        int i = 0;

        currentBet = 1.0f;
        float initialBet = currentBet;

        while (i <= numGames)
        {
            Bet();
            currentBet = initialBet;
            i++;
        }

        FillDropDown();
    }

	/**
	 * Function to check whether given parameter represents a positive number
	 */
    private bool IsNumber(char[] array)
    {

        char[] numbers = "0123456789".ToCharArray();

        // if empty array
        if (array.Length == 0)
            return false;

        // if first number in the field is 0, 0 is not valid for width
        if (array[0] == numbers[0])
        {
            return false;
        }

        int numberCount = 0;
        //sanity check, all chars must be numbers
        for (int i = 0; i < array.Length; i++)
        {
            char c = array[i];
            // check if current char is any of 1,2,3 ... 9
            for (int j = 0; j < numbers.Length; j++)
            {
                // if char is a number
                if (c == numbers[j])
                {
                    numberCount++;
                    continue;
                }
            }
        }
        // if all char in array are numbers
        return numberCount == array.Length;
    }

	/**
	 * Sets a new bet to the graph
	 */
    public void SetBet(){

        string text = betField.text;

        char[] ch = text.ToCharArray();

        if (!IsNumber(ch))
        {

            if (text.StartsWith("w: ")) {
                string[] s = text.Split(" "[0]);
                string second = s[1];
                int ng = int.Parse(second);
                numGames = ng;
                XAxis(numGames * unitWidth);
            }

            return;
        }

        float bet = float.Parse(text);

        if (bet < 0 || bet > 100)
            return;

        currentBet = bet;

        currentBetText.text = "" + currentBet;
    
    }

	/**
	 * Shows bet data element from the graph which is the parameter in this function
	 */
    public void ShowData(BetInfo bi) {
        panel.SetActive(true);

        GameObject date = panel.transform.FindChild("Date").gameObject;
        GameObject teamsAndResult = panel.transform.Find("TeamsAndResult").gameObject;
        GameObject homeOdd = panel.transform.Find("HomeOdd").gameObject;
        GameObject drawOdd = panel.transform.Find("DrawOdd").gameObject;
        GameObject awayOdd = panel.transform.Find("AwayOdd").gameObject;

        Text resultSoFar = panel.transform.FindChild("ResultSoFarAmount").GetComponent<Text>();
        resultSoFar.text = "" + bi.resultBefore;

        if (bi.resultBefore >= 0)
        {

            resultSoFar.color = Color.green;
        }
        else {
            resultSoFar.color = Color.red;
        }

        Text result = panel.transform.FindChild("ResultAmount").GetComponent<Text>();
        result.text = "" + bi.result;

        if (bi.result >= 0)
        {

            result.color = Color.green;
        }
        else
        {
            result.color = Color.red;
        }

        Text totalResult = panel.transform.FindChild("TotalResultAmount").GetComponent<Text>();
        totalResult.text = "" + bi.totalAmount;

        if (bi.totalAmount >= 0)
        {
            totalResult.color = Color.green;
        }
        else {
            totalResult.color = Color.red;
        }

        Text currentBetAmount = panel.transform.FindChild("CurrentBetAmount").GetComponent<Text>();
        currentBetAmount.text = "" + bi.currentBetAmount;

        if (bi.sportsEvent != null)
        {
            date.GetComponent<Text>().text = bi.sportsEvent.GetDate() + " (" + bi.index + ")"; ;
            teamsAndResult.GetComponent<Text>().text = bi.sportsEvent.GetMatchTeams() + " " + bi.sportsEvent.GetResult();

            homeOdd.GetComponentInChildren<Text>().text = "" + bi.sportsEvent.homeWinOdd;
            drawOdd.GetComponentInChildren<Text>().text = "" + bi.sportsEvent.drawOdd;
            awayOdd.GetComponentInChildren<Text>().text = "" + bi.sportsEvent.awayWinOdd;

            if (bi.sportsEvent.result == "1") {

                if (winCondition == 0) {
                    if (bi.sportsEvent.homeTeamName == AnalyzeSet.currentTeam)
                    {
                        homeOdd.GetComponentInChildren<Text>().color = Color.white;
                        homeOdd.GetComponent<Image>().color = Color.green;
                    }
                    else
                    { // loss
                        homeOdd.GetComponentInChildren<Text>().color = Color.white;
                        homeOdd.GetComponent<Image>().color = Color.red;
                    }
                }
                else if (winCondition == 1) {

                    homeOdd.GetComponentInChildren<Text>().color = Color.white;
                    homeOdd.GetComponent<Image>().color = Color.red;

                }
                else if (winCondition == 2) {
                    if (bi.sportsEvent.awayTeamName == AnalyzeSet.currentTeam)
                    {
                        homeOdd.GetComponentInChildren<Text>().color = Color.white;
                        homeOdd.GetComponent<Image>().color = Color.green;
                    }
                    else
                    { 
                        homeOdd.GetComponentInChildren<Text>().color = Color.white;
                        homeOdd.GetComponent<Image>().color = Color.red;
                    }
                }

                drawOdd.GetComponent<Image>().color = Color.white;
                awayOdd.GetComponent<Image>().color = Color.white;

                drawOdd.GetComponentInChildren<Text>().color = Color.black;
                awayOdd.GetComponentInChildren<Text>().color = Color.black;

            }
            else if (bi.sportsEvent.result == "X") {

                if (winCondition == 0) {
                    drawOdd.GetComponent<Image>().color = Color.red;
                    drawOdd.GetComponentInChildren<Text>().color = Color.white;
                }
                else if (winCondition == 1) {
                    drawOdd.GetComponent<Image>().color = Color.green;
                    drawOdd.GetComponentInChildren<Text>().color = Color.white;
                }
                else if (winCondition == 2) {
                    drawOdd.GetComponent<Image>().color = Color.red;
                    drawOdd.GetComponentInChildren<Text>().color = Color.white;
                }

                homeOdd.GetComponent<Image>().color = Color.white;
                homeOdd.GetComponentInChildren<Text>().color = Color.black;
                awayOdd.GetComponent<Image>().color = Color.white;
                awayOdd.GetComponentInChildren<Text>().color = Color.black;


            }
            else if (bi.sportsEvent.result == "2") {

                if (winCondition == 0) {
                    if (bi.sportsEvent.awayTeamName == AnalyzeSet.currentTeam)
                    {
                        awayOdd.GetComponent<Image>().color = Color.green;
                        awayOdd.GetComponentInChildren<Text>().color = Color.white;

                    }
                    else
                    { // loss
                        awayOdd.GetComponent<Image>().color = Color.red;
                        awayOdd.GetComponentInChildren<Text>().color = Color.white;
                    }
                }
                else if (winCondition == 1) {
                    awayOdd.GetComponent<Image>().color = Color.red;
                    awayOdd.GetComponentInChildren<Text>().color = Color.white;
                }
                else if (winCondition == 2) {

                    if (bi.sportsEvent.homeTeamName == AnalyzeSet.currentTeam)
                    {
                        awayOdd.GetComponent<Image>().color = Color.green;
                        awayOdd.GetComponentInChildren<Text>().color = Color.white;

                    }
                    else
                    { // loss
                        awayOdd.GetComponent<Image>().color = Color.red;
                        awayOdd.GetComponentInChildren<Text>().color = Color.white;
                    }
                }

                homeOdd.GetComponent<Image>().color = Color.white;
                homeOdd.GetComponentInChildren<Text>().color = Color.black;
                drawOdd.GetComponent<Image>().color = Color.white;
                drawOdd.GetComponentInChildren<Text>().color = Color.black;

            }

        }
        else
        {
            date.GetComponent<Text>().text = "No Date" + " (" + bi.index + ")";
            teamsAndResult.GetComponent<Text>().text = "No Teams";
            homeOdd.GetComponentInChildren<Text>().text = "0.00";
            drawOdd.GetComponentInChildren<Text>().text = "0.00";
            awayOdd.GetComponentInChildren<Text>().text = "0.00";

            homeOdd.GetComponent<Image>().color = Color.green;
            drawOdd.GetComponent<Image>().color = Color.green;
            awayOdd.GetComponent<Image>().color = Color.green;

            homeOdd.GetComponentInChildren<Text>().color = Color.white;
            drawOdd.GetComponentInChildren<Text>().color = Color.white;
            awayOdd.GetComponentInChildren<Text>().color = Color.white;
        }
        
        
    }

	/**
	 * Hides bet data 
	 */
    public void HideData() {
        panel.SetActive(false);
    }

	/**
	 * Creates a data elements to the graph represented as a sphere
	 */
    public GameObject CreateBetSphere(int x, float y) {

        GameObject go = (GameObject)Instantiate(betInfoPrefab);
        GameObject info = go.transform.FindChild("Sphere").gameObject;
        info.transform.position = new Vector3(x * unitWidth, y * unitHeight, 0);
        return info;
    }

	
	/**
	 * Calculates how much we won or lost during this sports event round using bet always win for a team strategy
	 */
    public float CalculateWinResult(SportsEvent sportsEvent) {

        float resultOfThis = 0;

        if (sportsEvent.result == "1")
        { // home win

            // if win
            if (sportsEvent.homeTeamName == AnalyzeSet.currentTeam)
            {
                float winMultiplier = sportsEvent.homeWinOdd - 1.0f;
                resultOfThis = winMultiplier * currentBet;

            }
            else
            { // loss

                resultOfThis = -currentBet;
            }

        }
        else if (sportsEvent.result == "X")
        { // tie

            resultOfThis = -currentBet;

        }
        else if (sportsEvent.result == "2")
        { // away win

            // if win
            if (sportsEvent.awayTeamName == AnalyzeSet.currentTeam)
            {
                float winMultiplier = sportsEvent.awayWinOdd - 1.0f;
                resultOfThis = winMultiplier * currentBet;
            }
            else
            { // loss
                resultOfThis = -currentBet;
            }
        }

        return resultOfThis;
    }

	/**
	 * Calculates how much we won or lost during this sports event round using bet always tie for a team strategy
	 */
    public float CalculateTieResult(SportsEvent sportsEvent)
    {

        float resultOfThis = 0;

        if (sportsEvent.result == "1")
        {
            resultOfThis = -currentBet;

        }
        else if (sportsEvent.result == "X")
        { // tie

            float winMultiplier = sportsEvent.drawOdd - 1.0f;
            resultOfThis = winMultiplier * currentBet;

        }
        else if (sportsEvent.result == "2")
        { // away win
            resultOfThis = -currentBet;
        }

        return resultOfThis;
    }

	/**
	 * Calculates how much we won or lost during this sports event round using bet always lose for a team strategy
	 */
    public float CalculateLossResult(SportsEvent sportsEvent)
    {

        float resultOfThis = 0;

        if (sportsEvent.result == "1")
        {
            if (sportsEvent.awayTeamName == AnalyzeSet.currentTeam)
            {
                float winMultiplier = sportsEvent.homeWinOdd - 1.0f;
                resultOfThis = winMultiplier * currentBet;
            }
            else { 
                // current team is playing at home and won
                resultOfThis = -currentBet;
            }

        }
        else if (sportsEvent.result == "X")
        { // tie
            resultOfThis = -currentBet;

        }
        else if (sportsEvent.result == "2")
        { // away win
            if (sportsEvent.homeTeamName == AnalyzeSet.currentTeam)
            {
                float winMultiplier = sportsEvent.awayWinOdd - 1.0f;
                resultOfThis = winMultiplier * currentBet;
            }
            else
            {
                // current team is playing a away game and won
                resultOfThis = -currentBet;
            }
        }

        return resultOfThis;
    }

	/**
	 * Places a new bet (point) into the analyzable graph
	 */ 
    public void Bet() {

        float resultOfThis = 0.0f;

        if (playIndex - 1 >= AnalyzeSet.games.Count)
            return;

        if (playIndex == 0)
        {
            GameObject go = CreateBetSphere(0, 0);
            BetInfo bi = go.GetComponent<BetInfo>();
            bi.result = 0;
            bi.resultBefore = 0;
            bi.totalAmount = 0;
            bi.currentBetAmount = 0;
            bi.index = playIndex;

            betInfos.Add(bi);

        }
        else {


            SportsEvent sportsEvent = AnalyzeSet.games[playIndex - 1];

            if (winCondition == 0) {
                resultOfThis = CalculateWinResult(sportsEvent);
            }
            else if (winCondition == 1) {
                resultOfThis = CalculateTieResult(sportsEvent);
            }
            else if (winCondition == 2) {
                resultOfThis = CalculateLossResult(sportsEvent);
            }


            BetInfo betInfo = betInfos[playIndex - 1];

            float resultBefore = betInfo.totalAmount;
            float totalAmount = resultBefore + resultOfThis;

            GameObject go = CreateBetSphere(playIndex, totalAmount);
            BetInfo bi = go.GetComponent<BetInfo>();
            bi.sportsEvent = AnalyzeSet.games[playIndex - 1];
            bi.resultBefore = resultBefore;
            bi.result = resultOfThis;
            bi.totalAmount = totalAmount;
            bi.currentBetAmount = currentBet;
            bi.index = playIndex;
            betInfos.Add(bi);


        
        }

        playIndex++;
    }

	/**
	 * Back to main menu
	 **/
    public void ToMenu(){
        SceneManager.LoadScene("Scenes/betAnalyzerApp");
    }

	
	/**
	 * Creates a visual X axis to the coordinate system
	 */
    private void XAxis(float length) {

        if (xAxisObjects.Count > 0) {
            for (int i = 0; i < xAxisObjects.Count; i++) {
                Destroy(xAxisObjects[i]);
            }

            xAxisObjects.Clear();
        }

        GameObject axis = (GameObject)Instantiate(cylinder, new Vector3(length/2.0f, 0, 0), Quaternion.AngleAxis(90, new Vector3(0, 0, 1)));
        axis.transform.localScale = new Vector3(0.1f, length/2.0f , 0.1f);
        xAxisObjects.Add(axis);

        for (float i = unitWidth; i <= length; i += unitWidth)
        {
            GameObject c = (GameObject)Instantiate(capsule, new Vector3(i, 0, 0), Quaternion.identity);
            xAxisObjects.Add(c);
        }
    
    }

	/**
	 * Creates a visual Y axis to the coordinate system
	 */
    private void YAxis(float length)
    {

        GameObject axis = (GameObject)Instantiate(cylinder, new Vector3(0, length/2.0f, 0), Quaternion.identity);
        axis.transform.localScale = new Vector3(0.1f, length/2.0f, 0.1f);

        for (float i = unitHeight; i <= length; i += unitHeight)
        {
            GameObject c = (GameObject)Instantiate(capsule, new Vector3(0, i, 0), Quaternion.AngleAxis(90, new Vector3(0, 0, 1)));
        }

    }


}
