﻿using UnityEngine;
using System.Collections;

/**
 * Represents a single archived game sports event
 **/
public class SportsEvent{

    public string leagueName; // name for league
    public int seasonStartYear; // the starting year of the season

    public string homeTeamName; // home team name 
    public string awayTeamName; // away team name

    public System.DateTime date; // date of the match

    public float homeWinOdd; // odd for home win
    public float drawOdd; // odd for draw
    public float awayWinOdd; // odd for away win

    public string result; // contains "1" for home win, "X" for tie or "2" for away win

    public int[] halfTimeGoals = new int[2]; // contains half time goals for home and away
    public int[] fullTimeGoals = new int[2]; // contains full time goals for home and away

    public SportsEvent() { }

    public string ToString() {

        string s = "";

        s += date.ToLongDateString() + " " + leagueName + " " + homeTeamName + " - " + awayTeamName + " (" + halfTimeGoals[0] + "-" + halfTimeGoals[1] + ") " + fullTimeGoals[0] + "-" + fullTimeGoals[1];
        s += " " + result + " " + homeWinOdd + " " + drawOdd + " " + awayWinOdd;
        return s;
    
    }

    public string GetString() {
        string s = "";

        s += homeTeamName + " - " + awayTeamName + "\t(" + halfTimeGoals[0] + "-" + halfTimeGoals[1] + ") " + fullTimeGoals[0] + "-" + fullTimeGoals[1];
        return s;
    }

    public string GetDate() {
        return date.ToLongDateString();
    }

    public string GetMatchTeams() {
        return "" + homeTeamName + " - " + awayTeamName;
    }

    public string GetResult() {
        return " " + fullTimeGoals[0] + "-" + fullTimeGoals[1];
    }

}
