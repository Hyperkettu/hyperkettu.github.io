﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/*
	This class represents the set of all matches that have been archived
*/
public class AnalyzeSet : MonoBehaviour {

    public static List<SportsEvent> games = new List<SportsEvent>(); // all the archived matches

    public static string currentTeam = "";

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
