﻿using UnityEngine;
using System.Collections;

using UnityEngine;
using System.Collections;

public class NHL : League
{

    // Use this for initialization
    void Start()
    {
        leagueName = "NHL";

    }

    // Update is called once per frame
    void Update()
    {

    }

    /**
     * Adds team logos
     * */
    public override void AddLogosToTeams()
    {

        // load images from Resource folder
        Sprite[] sprites = Resources.LoadAll<Sprite>("Teams/NHL");
        for (int i = 0; i < sprites.Length; i++)
        {
            for (int j = 0; j < teams.Count; j++)
            {

                if (sprites[i].name == teams[j].name)
                {

                    teams[j].logo = sprites[i];
                }
            }
        }


    }
}