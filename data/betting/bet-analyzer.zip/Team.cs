﻿using UnityEngine;
using System.Collections;

/**
 * Represents a single team 
 */

public class Team {

    public string name; // name of the team
    public Sprite logo; // team logo

    public Team() { 
    }
}
