﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Collections.Generic;

/**
 * Represents a CSV reader to parse the archived match data from a CSV file
 */
public class CSVReader : MonoBehaviour {

    private static int averageHomeWinOddIndex; // index of average home win odd in parsed file
    private static int averageDrawOddIndex; // index of average draw odd in parsed file
    private static int averageAwayWinOddIndex; // index of average away win odd in parsed file
    private static int dateIndex; // index of match date in parsed file
    private static int leagueDivisionIndex; // index of league name in parsed file
    private static int homeTeamIndex; // index of home team name data in parsed file (away team index this + 1)
    private static int fullTimeHomeGoalsIndex; // index of full time home goals in parsed file (away goals index is this + 1)
    private static int halfTimeHomeGoalsIndex; // index of half time home goals in parsed file (away goals index is this + 1)


	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKey(KeyCode.Escape)) {
            Application.Quit();
        }
	}

    /**
     * Initializes index data for parsing a season file matches from data elements array
     * 
     * @param data elements to be parsed
     * */
    public static void InitIndicesOfRelevantFields(string[] dataElements){
    
        // find indices of relevant data elements
        leagueDivisionIndex = FindIndexOfKey(dataElements, "Div");
        homeTeamIndex = FindIndexOfKey(dataElements, "HomeTeam");

        fullTimeHomeGoalsIndex = FindIndexOfKey(dataElements, "FTHG");
        halfTimeHomeGoalsIndex = FindIndexOfKey(dataElements, "HTHG");
        
        averageHomeWinOddIndex = FindIndexOfKey(dataElements, "BbAvH");
        averageDrawOddIndex = FindIndexOfKey(dataElements, "BbAvD");
        averageAwayWinOddIndex = FindIndexOfKey(dataElements, "BbAvA");
        dateIndex = FindIndexOfKey(dataElements, "Date");
    }

    /**
     * Parses parameter CSV season file to a list of matches
     *
     * @param csv text asset file to parse
     * @return list of sports events
     * */
    public static List<SportsEvent> ParseSeasonFile(TextAsset seasonData)
    {

        string csvText = seasonData.text;
        // get lines to string array
        string[] lines = csvText.Split("\n"[0]);

        // get starting year of the season (data name file is of format "LeagueName-StartYear-EndYear.csv"
        int seasonStartYear = int.Parse(seasonData.name.Split("-"[0])[1]);
        string leagueName = seasonData.name.Split("-"[0])[0];

        // other lines represent matches so create a list of matches
        List<SportsEvent> matches = new List<SportsEvent>();
        for (int i = 1; i < lines.Length; i++) {
       
            // if we have data
            if (lines[i].Length > 0)
            {
                // parse match data
                string[] matchData = GetElementsOnLine(lines[i]);
                SportsEvent sportsEvent = GetSportsEvent(matchData);
                sportsEvent.seasonStartYear = seasonStartYear;
                sportsEvent.leagueName = leagueName;
                matches.Add(sportsEvent);
            }
        }
        
        return matches;
    }

    /**
     * This function generates a sports event from match data string array
     * 
     * @param match data to be converted 
     * @return sports event generated
     * */
    public static SportsEvent GetSportsEvent(string[] matchData) {

        SportsEvent e = new SportsEvent();

        // find match teams date
        e.date = ParseDate(matchData[dateIndex]);
        e.homeTeamName = matchData[homeTeamIndex];
        e.awayTeamName = matchData[homeTeamIndex + 1];

        // find half and full time results
        e.halfTimeGoals[0] = int.Parse(matchData[halfTimeHomeGoalsIndex]);
        e.halfTimeGoals[1] = int.Parse(matchData[halfTimeHomeGoalsIndex + 1]);
        e.fullTimeGoals[0] = int.Parse(matchData[fullTimeHomeGoalsIndex]);
        e.fullTimeGoals[1] = int.Parse(matchData[fullTimeHomeGoalsIndex + 1]);
        
        // home win
        if (e.fullTimeGoals[0] > e.fullTimeGoals[1]) {
            e.result = "1";
        }
        else if (e.fullTimeGoals[0] == e.fullTimeGoals[1]) // tie
        {
            e.result = "X";
        }
        else { // away win
            e.result = "2";
        }
        
        // find odds 
        e.homeWinOdd = float.Parse(matchData[averageHomeWinOddIndex]);
        e.drawOdd = float.Parse(matchData[averageDrawOddIndex]);
        e.awayWinOdd = float.Parse(matchData[averageAwayWinOddIndex]);
        
        return e;
    }

    /**
     * Generates sports event from data
     * 
     * @param line in url file
     * @return sport event
     * */
    public static SportsEvent GetSportsEvent(string line) {

        string[] matchData = line.Split(","[0]);

        SportsEvent e = new SportsEvent();

        // find match teams date
        e.leagueName = matchData[0];
        e.date = ParseDate(matchData[1]);
        e.homeTeamName = matchData[2];
        e.awayTeamName = matchData[3];

        // find full time result
        e.fullTimeGoals[0] = int.Parse(matchData[4]);
        e.fullTimeGoals[1] = int.Parse(matchData[5]);

        // home win
        if (e.fullTimeGoals[0] > e.fullTimeGoals[1])
        {
            e.result = "1";
        }
        else if (e.fullTimeGoals[0] == e.fullTimeGoals[1]) // tie
        {
            e.result = "X";
        }
        else
        { // away win
            e.result = "2";
        }

        // find odds 
        e.homeWinOdd = float.Parse(matchData[6]);
        e.drawOdd = float.Parse(matchData[7]);
        e.awayWinOdd = float.Parse(matchData[8]);

        return e;
    
    }

    /**
     * Functions parses date from the date string in form "dd::mm::yy"
     * 
     * @param date string to parse
     * @return date 
     * */
    public static System.DateTime ParseDate(string dateString) {

        string[] parts = dateString.Split("/"[0]);

        int day = int.Parse(parts[0]);
        int month = int.Parse(parts[1]);
        int year = 2000 + int.Parse(parts[2]);

        System.DateTime date = new System.DateTime(year, month, day);
        return date;
    }

    /**
     * This function returns the find index of parameter key in parameter array
     * 
     * @param array array to search the key from
     * @param string key to find index of
     * @return first index of key or -1 if not found
     * */
    public static int FindIndexOfKey(string[] array, string key) {

        // find the find index of a key
        for (int i = 0; i < array.Length; i++)
        {

            if (array[i] == key)
                return i;
        }
        // not found
        return -1;
    }


    /**
     * Returns data elements on a line of the season data CSV file
     * 
     * @param line string to parse
     * @return parse string array containing the elements
     * */
    public static string[] GetElementsOnLine(string line) {
        return line.Split(","[0]);
    }
}
