﻿using UnityEngine;
using System.Collections;

/**
 * Shows information of a single match in the graph that shows the analyzation data
 */
public class BetInfo : MonoBehaviour {

    public SportsEvent sportsEvent;

    public float resultBefore = 0;
    public float result = 0;
    public float totalAmount = 0;
    public float currentBetAmount = 0;

    public int index = 0;

    public bool showData = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

	}
}
