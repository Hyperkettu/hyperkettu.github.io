﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

	/**
	 * Represents a single league
	 */

public class League : MonoBehaviour {

    public string leagueName; // the name of the league
    public List<SportsEvent> matches = new List<SportsEvent>(); // matches played in this league
    public Sprite leagueLogo; // league logo

    public List<Team> teams = new List<Team>(); // list of teams

    //public bool teamsAdded = false;

	// Use this for initialization
	void Start () {
    
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public virtual void AddLogosToTeams() { }

    /**
     * Adds a team to this leagues with name
     * 
     * @param name of the team
     * */
    public void AddTeam(string teamName) {
        Team team = new Team();
        team.name = teamName;
        teams.Add(team);
    }

    /**
     * Adds matches to this league
     * 
     * @param list of matches to add
     * */
    public void AddMatches(List<SportsEvent> matchData) {

        for (int i = 0; i < matchData.Count; i++) {
            this.matches.Add(matchData[i]);
        }
    }

    /**
     * Adds a single sports event to the league
     * 
     * @param sportEvent Game to add
     * */
    public void AddMatch(SportsEvent se) {
        this.matches.Add(se);
    }

    /**
     * Adds teams to this league based on match history
     * */
    public void AddTeamsFromMatchData() {

        List<string> teamNames = new List<string>();

        // collect all team names
        for (int i = 0; i < matches.Count; i++) {

            if (!teamNames.Contains(matches[i].homeTeamName)) {
                teamNames.Add(matches[i].homeTeamName);
            }
        
        }

        for (int i = 0; i < teamNames.Count; i++) {
            AddTeam(teamNames[i]);
        }

    }

    /**
     * Sorts all matches syncronously
     * */
    public void SortMatchesSyncronously() {

        this.matches.Sort(
                delegate(SportsEvent e1, SportsEvent e2) 
                {
                    return e1.date.CompareTo(e2.date);
                }

            );
    
    }

    /**
     * Sorts teams alphabetically
     * */
    public void SortTeamsAlphabetically() {
        
        teams.Sort(
            delegate(Team i1, Team i2)
            {
                return i1.name.CompareTo(i2.name);
            }
        );
    }

    /**
     * Returns a syncronously sorted list of matches for the parameter team name
     * 
     * @param name of the team
     * @return list of games
     * */
    public List<SportsEvent> GetMatchesFor(string teamName) {

        List<SportsEvent> matchesForTeam = new List<SportsEvent>();

        // find all matches for a team
        for (int i = 0; i < matches.Count; i++) {

            SportsEvent sportEvent = matches[i];
            // either home or away match
            if (sportEvent.homeTeamName == teamName || sportEvent.awayTeamName == teamName) {
                matchesForTeam.Add(sportEvent);
            }
        
        }

        // sort games based on date, newest event first
        matchesForTeam.Sort(
                delegate(SportsEvent e1, SportsEvent e2)
                {
                    return e2.date.CompareTo(e1.date);
                }

            );

        return matchesForTeam;
    }

}
