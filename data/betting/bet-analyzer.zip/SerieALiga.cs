﻿using UnityEngine;
using System.Collections;

public class SerieALiga : League
{

    // Use this for initialization
    void Start()
    {
        leagueName = "Serie A";

    }

    // Update is called once per frame
    void Update()
    {

    }

    /**
     * Adds team logos
     * */
    public override void AddLogosToTeams()
    {

        // load images from Resource folder
        Sprite[] sprites = Resources.LoadAll<Sprite>("Teams/SerieA");
        for (int i = 0; i < sprites.Length; i++)
        {
            for (int j = 0; j < teams.Count; j++)
            {

                if (sprites[i].name == teams[j].name)
                {

                    teams[j].logo = sprites[i];
                }
            }
        }


    }
}