﻿using UnityEngine;
using System.Collections;

/**
 * This class contains tetromino specific data, all the tetrominos (I, O, J etc) have a derived data class 
 * */
public class TetrominoData {

    public int numberOfRotations; // number of rotations in this tetromino
    public Vector2[][] offsets; // offsets to other than center block for each rotation, offsets are relative to the block center (pivot)

    public int[][] indexToBlockToCheckRight; // indices to blocks to check when moving right
    public int[][] indexToBlockToCheckLeft; // indices to blocks to check when moving left
    public int[][] indexToBlockToCheckDown; // indices to blocks to check when moving down

    /**
     * Constructor
     * */
    public TetrominoData() {
    }

    /**
     * Sets block offset relative to block center for each rotation
     * */
    public virtual void SetOffsetsOfBlocks() {
    }

    /**
     * Initializes index to block data structures used to calculate whether moving right, left and down is possible
     * */
    public virtual void InitIndicesToBlocks() {
    }

    /**
     * Returns offsets to block relative position on tetromino center (pivot) block for specific rotation
     * 
     * @param rotation index 
     * @return Vector2 array of offsets
     * */ 
    public Vector2[] GetOffset(int rotation)
    {
        return offsets[rotation];
    }

}
