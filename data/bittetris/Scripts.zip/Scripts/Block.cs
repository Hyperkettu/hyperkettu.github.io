﻿using UnityEngine;
using System.Collections;

/**
 * This class represents a block, one tetromino consists of 4 blocks, blocks are also placed on the play field
 * */
public class Block : MonoBehaviour {

	public enum BlockType { Normal = 0, Stone };
    public static Color[] colors = new Color[] { Color.red, Color.green, Color.blue, Color.magenta, Color.white, Color.yellow, Color.cyan}; // predefined colors for blocks
    public Vector2 position = new Vector2(); // position of this block, x in range [0, gridWidth - 1], y in range [0, gridHeight - 1]
    public bool removeFlag = false; // flag set to true if desired to be removed
	public BlockType type;


    /**
     *  Sets the color for this block
     *  
     * @param color to be set
     * */
    public void SetColor(Color color) {
        GetComponent<SpriteRenderer>().color = color;
    }

	/**
     *  Returns the color of this block
     *  
     * @return color
     * */
	public Color GetColor() {
		return GetComponent<SpriteRenderer> ().color;
	}

    /**
     *  Static function that returns a random color from the colors in the array Block.colors
     *  
     * @return random color
     * */
    public static Color RandomColor() {
        int randomNumber = Random.Range(0, Block.colors.Length);
        return Block.colors[randomNumber];
    }

    /**
     * Sets the position of this block in grid coordinates, calculates the position for Transform object
     * 
     * @param x coordinate varies from range [0, gridWidth - 1]
     * @param y coordinate varies from range[0, gridHeigth - 1]
     * 
     * */
    public void SetLocation(int x, int y) {
        Vector3 pos = new Vector2(x * Grid.blockDimension + Grid.blockDimension / 2.0f, y * Grid.blockDimension + Grid.blockDimension / 2.0f);
        transform.localPosition = pos;
        position.x = x;
        position.y = y;
    }

    /**
     * Sets the position of this big block in grid coordinates, calculates the position for Transform object
     * 
     * @param x coordinate varies from range [0, gridWidth - 1]
     * @param y coordinate varies from range[0, gridHeigth - 1]
     * 
     * */
    public void SetLocationBig(float x, float y)
    {
        Vector3 pos = new Vector2(x * Grid.blockDimension + Grid.blockDimension / 2.0f, y * Grid.blockDimension + Grid.blockDimension / 2.0f);
        transform.localPosition = pos;
        position.x = x;
        position.y = y;
    }

	/**
	 * Hides this block from the player
	 * */
    public void HideBlock()
    {
        GetComponent<SpriteRenderer>().enabled = false;
    }

}
