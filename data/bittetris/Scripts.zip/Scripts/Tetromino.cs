﻿using UnityEngine;
using System.Collections;

public class Tetromino : MonoBehaviour {

    // contains data for each tetromino type
    static TetrominoData[] tetrominoData = { new ITetrominoData(), new OTetrominoData(), new TTetrominoData(), new JTetrominoData(), new LTetrominoData(), new STetrominoData(), new ZTetrominoData(), 
		new EvilminoData(), new GoodminoData()};
    public enum Type { I = 0, O, T, J, L, S, Z, Evilmino, Goodmino, NumTetrominos }; // types of the tetrominos

    public int x; //coordinate x of the center of the tetromino in grid range [0, width - 1]
    public int y; // coordinate y of the center of the tetromino in grid range [0, height - 1]

    public Type tetroType; // type of this tetromino

    public GameObject blockPrefab; // prefab to instanciating blocks
    public GameObject evilPrefab; // prefab to instancing evil blocks
	public GameObject goodPrefab; // prefab to instancing good blocks
	public ParticleSystem explosion; // prefab to instancing explosions

    private Block[] blocks = new Block[4]; // tetromino consists of 4 blocks 
    private Block bigBlock;
    private TetrominoData data; // data of this tetromino
    private int rotationState = 0; // integer represents a rotation state

    /**
     * Returns tetromino center block position
     * 
     * @return center block position
     * */
    public Vector3 GetPosition() {
        return this.blocks[0].transform.position;
    }

	/**
	 * Returns big block
	 * 
	 * @return bigBlock of this big mino
	 * */
	public Block getBigBlock(){
		return bigBlock;
	}

    /**
     * This function is a getter for a block of specified index
     * 
     * @param index
     * @return block of the index
     * */
    public Block GetBlock(int index) {
        return this.blocks[index];
    }

    /**
     * Sets this tetromino to a position corresponding coordinate y, x coordinate remains the same
     * 
     * @param coordinate y to set to
     * */
    public void SetPositionY(int y) {

        this.y = y;
        // set the position to center block
        blocks[0].SetLocation(x, y);

        Vector2[] offsets = this.data.offsets[this.rotationState];

        // update each block to new position
        for (int i = 0; i < 3; i++)
        {
            Block block = blocks[i+1];
            int blockX = x + (int)offsets[i].x;
            int blockY = y + (int)offsets[i].y;
            block.SetLocation(blockX, blockY);
        }
    }

    /**
     * This function moves this tetromino with dx and dy
     * 
     * @param dx delta x
     * @param dy delta y
     * */
    public void Move(int dx, int dy) 
    {
        // move tetromino center
        this.x += dx;
        this.y += dy;

        // move each block to new position
        for (int i = 0; i < 4; i++) {
            Block block = blocks[i];
            int blockX = (int) block.position.x;
            int blockY = (int) block.position.y;
            blockX += dx;
            blockY += dy;
            block.SetLocation(blockX, blockY);
        }

        // if we have a big block
        if ((int)tetroType > 6) {
            bigBlock.SetLocationBig(blocks[0].position.x + 0.5f, blocks[0].position.y - 0.5f);
        }
    }

    /**
     * Moves this tetromino left by one
     * */
    public void MoveLeft() {
        Move(-1, 0);
    }


    /**
     * Moves this tetromino right by one
     * */
    public void moveRight()
    {
      Move(1, 0);
    }


    /**
     * Returns the indices to blocks whose right side should be checked to determine if moving to right is possible
     * 
     * @return index to blocks
     * */
    public int[] GetRightSideIndices() {
        return this.data.indexToBlockToCheckRight[this.rotationState];
    }

    /**
    * Returns the indices to blocks whose left side should be checked to determine if moving to left is possible
    * 
    * @return index to blocks
    * */
    public int[] GetLeftSideIndices()
    {
        return this.data.indexToBlockToCheckLeft[this.rotationState];
    }


    /**
    * Returns the indices to blocks whose down side should be checked to determine if moving to down is possible
    * 
    * @return index to blocks
    * */
    public int[] GetDownSideIndices() {
        return this.data.indexToBlockToCheckDown[this.rotationState];
    }

    /**
     * Moves tetromino down
     * */
    public void MoveDown() {
        Move(0, -1);
    }

    /**
     * Rotates this tetromino
     * */
    public void Rotate() {
        // get next rotation
        this.rotationState = (this.rotationState + 1) % this.data.numberOfRotations;
       Vector2[] offs = this.data.GetOffset(this.rotationState);

        // set all blocks (except center block) to new positions
       for (int i = 0; i < offs.Length; i++) {
           Block block = blocks[i + 1];
           Vector2 offset = offs[i];
           int blockX = x + (int) offset.x;
           int blockY = y + (int) offset.y;
           block.SetLocation(blockX, blockY);
       }

       
    }

    /**
     * Returns offsets (relative to center block) to blocks based on number argument (i = 0 means current rotation, i = 1 means next rotation etc)
     * 
     * @param i which rotation is desired
     * @return Vector2 array of offsets to positions for desired rotation
     * */
    public Vector2[] GetRotationOffsetsOfBlocks(int i) {
        return this.data.GetOffset((this.rotationState + 1) % this.data.numberOfRotations);
    }

    /**
     * Initializes the tetromino data
     * 
     * @param type of the tetromino (I, O, J, etc)
     * @param x coordinate
     * @param y coordinate
     * @param grid to place the tetromino
     * */
    public void CreateTetromino(int type, int x, int y, Grid grid) {

        this.x = x;
        this.y = y;
        
        // get correct data based on tetromino type
        //int t = 7;
        data = tetrominoData[type];
        //data = tetrominoData[t];
        tetroType = (Type) type;

        // random color
        Color col = Block.RandomColor();
        // create center block
        GameObject center = CreateBlock(x, y, col, grid);
        blocks[0] = center.GetComponent<Block>();

        // create other blocks based on offset data
        Vector2[] offs = this.data.GetOffset(this.rotationState);

        for (int i = 0; i < offs.Length; i++) {
            Vector2 offset = offs[i];
            int blockX = x + (int) offset.x;
            int blockY = y + (int) offset.y;
            GameObject go = CreateBlock(blockX, blockY, col, grid);
            blocks[i + 1] = go.GetComponent<Block>();
        }

		if (tetroType == Type.Evilmino) {
			GameObject big = CreateBigBlock (x, y, col, grid, false);
			bigBlock = big.GetComponent<Block> ();
			bigBlock.SetLocationBig (blocks [0].position.x + 0.5f, blocks [0].position.y - 0.5f);

			for (int i = 0; i < 4; i++) {
				blocks [i].HideBlock ();
			}
		} else if (tetroType == Type.Goodmino) {
			GameObject big = CreateBigBlock (x, y, col, grid, true);
			bigBlock = big.GetComponent<Block> ();
			bigBlock.SetLocationBig (blocks [0].position.x + 0.5f, blocks [0].position.y - 0.5f);

			for (int i = 0; i < 4; i++) {
				blocks [i].HideBlock ();
			}
		}
        
    }

	/**
	 * Helper function to creating either goodmino or evilmino
	 * 
	 * @param x X coordinate
	 * @param y Y coordinate
	 * @param color Initial color of this block
	 * @param grid Play field 
	 * @param isGood Boolean indicating whether goodmino should be created (otherwise evilmino)
	 * @return block just created
	 * */
	public GameObject CreateBigBlock(int x, int y, Color color, Grid grid, bool isGood) {

		GameObject blockGameObject;
		if (!isGood)
			blockGameObject = (GameObject)Instantiate (evilPrefab, Vector2.zero, Quaternion.identity) as GameObject;
		else
			blockGameObject = (GameObject)Instantiate (goodPrefab, Vector2.zero, Quaternion.identity) as GameObject;
        blockGameObject.transform.parent = grid.transform;
        Block block = blockGameObject.GetComponent<Block>();
        block.SetLocation(x, y);
        block.SetColor(color);
        return blockGameObject;
    }

    /**
     * Helper function to creating block to specific position with a color
     * 
     * @param x coordinate in the grid
     * @param y coordinate in the grid
     * @param color of the block
     * @return game object of the block instance
     */
    public GameObject CreateBlock(int x, int y, Color color, Grid grid) { 
    
        GameObject blockGameObject = (GameObject)Instantiate(blockPrefab, Vector2.zero, Quaternion.identity) as GameObject;
        blockGameObject.transform.parent = grid.transform;
        Block block = blockGameObject.GetComponent<Block>();
        block.SetLocation(x,y);
        block.SetColor(color);
		block.type = Block.BlockType.Normal;
        return blockGameObject;
    }

	/**
	 * Thread for shaking this tetromino
	 * */
	IEnumerator Shake(){

		int locations = 30;
		float maxDistance = 0.15f;
		float minDistance = 0.1f;

		Vector3 initialPosition = bigBlock.transform.position;
		Vector3[] locs = new Vector3[locations + 1];

		// define some offsets
		for (int i = 0; i < locations; i++)
		{
			float radius = Random.Range(minDistance, maxDistance);
			Vector2 direction = Random.insideUnitCircle;
			Vector3 target = initialPosition + radius * new Vector3(direction.x, direction.y, 0);
			locs[i] = target;
		}

		locs[locations] = initialPosition;

		float speed = 10.5f;
		int index = 0;

		while (true)
		{
			// move camera towards a target position
			bigBlock.transform.position = Vector3.MoveTowards(bigBlock.transform.position, locs[index], speed * Time.deltaTime);

			// if camera is close enough a target, switch to next target
			if((bigBlock.transform.position-locs[index]).magnitude < 0.001f){
				index++;

				// if all targets reached already, quit the thread
				if (index == locations + 1)
					break;
			}

			yield return new WaitForSeconds(0.01f);

		}
		// set back to initial position
		bigBlock.transform.position = initialPosition;

		// starts explosion
		Instantiate (explosion, bigBlock.transform.position, Quaternion.identity);


	}

    /**
     * Starts animating this tetromino's color
     * */
    public void AnimateTetrominoColor() {

        if ((int)tetroType > 6)
        {
            StartCoroutine("AnimateColorBig");
        }
        else
        {
            StartCoroutine("AnimateColor");
        }
    }

    /**
     * Animates colors of all 4 blocks until tetromino is destroyed
     * 
     * @return IEnumerator for this thread
     * */
    IEnumerator AnimateColorBig()
    {

        SpriteRenderer renderer = GetBlock(0).GetComponent<SpriteRenderer>();
        Color initialColor = renderer.color;
        // find random color
        float r = Random.Range(0.0f, 1.0f);
        float g = Random.Range(0.0f, 1.0f);
        float b = Random.Range(0.0f, 1.0f);
        Color random = new Color(r, g, b);

        float duration = 0.4f;
        Color color;

        // animate duration time
        while (true)
        {
            // animate color between original and random
            float t = Mathf.PingPong(Time.time, duration) / duration;
            color = Color.Lerp(initialColor, random, t);
            yield return new WaitForSeconds(0.1f);
            // change color for big block
            bigBlock.SetColor(color);
            
        }
    }

    /**
     * Animates colors of all 4 blocks until tetromino is destroyed
     * 
     * @return IEnumerator for this thread
     * */
    IEnumerator AnimateColor()
    {

        SpriteRenderer renderer = GetBlock(0).GetComponent<SpriteRenderer>();
        Color initialColor = renderer.color;
        // find random color
        float r = Random.Range(0.0f, 1.0f);
        float g = Random.Range(0.0f, 1.0f);
        float b = Random.Range(0.0f, 1.0f);
        Color random = new Color(r, g, b);

        float duration = 0.4f;
        Color color;

        // animate duration time
        while (true)
        {
            // animate color between original and random
            float t = Mathf.PingPong(Time.time, duration) / duration;
            color = Color.Lerp(initialColor, random, t);
            yield return new WaitForSeconds(0.1f);
            // change color for each block
            for (int i = 0; i < 4; i++) {
                blocks[i].GetComponent<SpriteRenderer>().color = color;
            }
        }
    }
}
