﻿using UnityEngine;
using System.Collections;

/**
 * Tetromino T related data
 * */
public class TTetrominoData : TetrominoData {

    public TTetrominoData() {
        this.numberOfRotations = 4;
        SetOffsetsOfBlocks();
        InitIndicesToBlocks();

       
    }

    public override void SetOffsetsOfBlocks()
    {

        offsets = new Vector2[this.numberOfRotations][];

        for (int i = 0; i < offsets.Length; i++)
        {
            offsets[i] = new Vector2[3];
        }

        // first rotation
        offsets[0][0] = new Vector2(-1, 0);
        offsets[0][1] = new Vector2(1, 0);
        offsets[0][2] = new Vector2(0, -1);

        // second rotation
        offsets[1][0] = new Vector2(0, 1);
        offsets[1][1] = new Vector2(0, -1);
        offsets[1][2] = new Vector2(-1, 0);

        // third rotation
        offsets[2][0] = new Vector2(1, 0);
        offsets[2][1] = new Vector2(-1, 0);
        offsets[2][2] = new Vector2(0, 1);

        // fourth rotation
        offsets[3][0] = new Vector2(0, -1);
        offsets[3][1] = new Vector2(0, 1);
        offsets[3][2] = new Vector2(1, 0);
    }

    public override void InitIndicesToBlocks()
    {
        // RIGHT SIDE INDICES
        indexToBlockToCheckRight = new int[this.numberOfRotations][];

        // first rotation
          indexToBlockToCheckRight[0] = new int[2] {2, 3};
        // second rotation
        indexToBlockToCheckRight[1] = new int[3] {0, 1, 2};
        // third rotation
        indexToBlockToCheckRight[2] = new int[2] {1, 3};
        // fourth rotation
        indexToBlockToCheckRight[3] = new int[3] {1 ,2, 3};


        // LEFT SIDE INDICES
        indexToBlockToCheckLeft = new int[this.numberOfRotations][];

        // first rotation
        indexToBlockToCheckLeft[0] = new int[2] {1, 3};
        // second rotation
        indexToBlockToCheckLeft[1] = new int[3] {1, 2, 3};
        // third rotation
        indexToBlockToCheckLeft[2] = new int[2] {2, 3};
        // fourth rotation
        indexToBlockToCheckLeft[3] = new int[3] {0, 1, 2};

        // DOWN SIDE INDICES
        indexToBlockToCheckDown = new int[this.numberOfRotations][];

        // first rotation
        indexToBlockToCheckDown[0] = new int[3] {1, 2, 3};
        // second rotation
        indexToBlockToCheckDown[1] = new int[2] {2, 3};
        // third rotation
        indexToBlockToCheckDown[2] = new int[3] {0, 1, 2};
        // fourth rotation
        indexToBlockToCheckDown[3] = new int[2] {1, 3};

    }
}
