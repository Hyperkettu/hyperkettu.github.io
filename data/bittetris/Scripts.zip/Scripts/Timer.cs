﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

/**
 * This class represents a timer
 * */ 
public class Timer : MonoBehaviour {

    protected Text timerText; // timer text label
    protected int timeInSeconds; // time in seconds

    void Start() { 
        timerText = GetComponent<Text>();
    }

    /**
     * Resets the time to zero
     * */
    public virtual void Reset() {
        timeInSeconds = 0;

        
    }

    /**
     * Starts the timer
     * */
    public virtual void StartTimer() {
        StartCoroutine("TimerThread");
    }

    /**
     * Stops the timer
     * */
    public virtual void StopTimer() {
        StopCoroutine("TimerThread");
    }

    /**
     * This function updates the timer text
     * */
    protected void UpdateText() {

        // calculate time variables
        int minutes = timeInSeconds / 60;
        int seconds = timeInSeconds - minutes * 60;
        timerText.text = "";

        // fill the label with text
        if (minutes < 10) {
            timerText.text = "0";
        }

        timerText.text = timerText.text + minutes + ":";

        if (seconds < 10) {
            timerText.text = timerText.text + "0";
        }

        timerText.text = timerText.text + seconds;
    }

    /**
     * Increments time every second and update text field
     * */
    IEnumerator TimerThread() {
        while (true) { 
            // wait one second
            yield return new WaitForSeconds(1.0f);
            timeInSeconds++;
            UpdateText();
        }
    }
}
