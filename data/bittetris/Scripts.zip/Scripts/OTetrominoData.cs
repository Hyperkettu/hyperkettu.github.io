﻿using UnityEngine;
using System.Collections;

/**
 * Tetromino O related data
 * */
public class OTetrominoData : TetrominoData {

    public OTetrominoData() {
        this.numberOfRotations = 1;
        SetOffsetsOfBlocks();
        InitIndicesToBlocks();
    }

    public override void SetOffsetsOfBlocks()
    {

        // initialize arrays
        offsets = new Vector2[this.numberOfRotations][];

        for (int i = 0; i < offsets.Length; i++)
        {
            offsets[i] = new Vector2[3];
        }
        // first rotation (and only)
        offsets[0][0] = new Vector2(1, 0);
        offsets[0][1] = new Vector2(0, -1);
        offsets[0][2] = new Vector2(1, -1);

    }

    public override void InitIndicesToBlocks()
    {

        // initialize right indices
        indexToBlockToCheckRight = new int[this.numberOfRotations][];

        // first rotation indices to check when moving right
        indexToBlockToCheckRight[0] = new int[2];
        indexToBlockToCheckRight[0][0] = 1;
        indexToBlockToCheckRight[0][1] = 3;

        // initialize left indices
        indexToBlockToCheckLeft = new int[this.numberOfRotations][];

        // first rotation indices to check when moving left
        indexToBlockToCheckLeft[0] = new int[2];
        indexToBlockToCheckLeft[0][0] = 0;
        indexToBlockToCheckLeft[0][1] = 2;

        // initialize down indices
        indexToBlockToCheckDown = new int[this.numberOfRotations][];

        // first rotation (and only)
        indexToBlockToCheckDown[0] = new int[2];
        indexToBlockToCheckDown[0][0] = 2;
        indexToBlockToCheckDown[0][1] = 3;
    }
    
}
