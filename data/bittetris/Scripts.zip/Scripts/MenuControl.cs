﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

using System.IO;
/**
 * Class controls main menu
 * */ 
public class MenuControl : MonoBehaviour {

    public Text bestScoreLabel; // best score label
    public Text widthLabel; // label for width
    public Text heightLabel; // label for height

    public InputField widthField; // input field for width
    public InputField heightField; // input field for height

    public AudioClip clickClip; // click audio clip

    private AudioSource audio; // audio source

	// Use this for initialization
	void Start () {

        Screen.orientation = ScreenOrientation.Portrait;

		// if highscore file already exists, read highest score from there
		if (File.Exists (Application.persistentDataPath + "/myFile.txt")) {
			StreamReader sr = new StreamReader (Application.persistentDataPath + "/myFile.txt");
			string line = sr.ReadLine ();
			GameData.highestScore = int.Parse (line);
		}

        // initialize audio source
        audio = GetComponent<AudioSource>();

        // update best score label
        UpdateBestScoreLabel();

        // grid dimension are 0, change to default values, height = 20, width = 10
        if (GameData.gridHeight == 0) {
            GameData.gridHeight = 20;
        }
        if (GameData.gridWidth == 0) {
            GameData.gridWidth = 10;
        }
        // update label texts
        widthLabel.text = GameData.gridWidth.ToString();
        heightLabel.text = GameData.gridHeight.ToString();
	}
	
	// Update is called once per frame
	void Update () {

        // if should quit
        if (Input.GetKeyDown(KeyCode.Escape))
            Application.Quit();
	}

    /**
     * This function updates the best score label
     * */
    public void UpdateBestScoreLabel() {
        bestScoreLabel.text = "Best Score: " + GameData.highestScore;
    }

    /**
     * Handles start button click, play sound and start game
     * */
    public void HandleStartClick() {
        audio.clip = clickClip;
        audio.Play();
        StartCoroutine("StartThread");
    }

    /**
     *  This function starts the game
     * */
    public void StartGame() {
        SceneManager.LoadScene("Scenes/tetris");
    }

    /**
     * Start game thread, starts the game after click audio clip has run
     * */
    IEnumerator StartThread() {
        yield return new WaitForSeconds(0.35f);
        StartGame();
    }

	/**
	 * Handle button click for how to play screen
	 * */
	public void HandleHowToPlay(){
		audio.clip = clickClip;
		Invoke ("OpenHowToPlay", 0.35f);
	}

	/**
	 * Opens how to play scene
	 * */
	public void OpenHowToPlay(){

		SceneManager.LoadScene ("Scenes/howtoplay");
	}

    /**
     * This function set the width variable according to width input field
     * */ 
    public void SetWidth() {

        char[] ch = widthField.text.ToCharArray();

        // if not number do not change width
        if (!IsNumber(ch))
            return;

        GameData.gridWidth = int.Parse(widthField.text);
        widthLabel.text = GameData.gridWidth.ToString();

        widthField.text = "";

    }

    /**
     * This function set the height variable according to height input field
     * */
    public void SetHeight() {

        char[] ch = heightField.text.ToCharArray();

        // if not number do not change height
        if (!IsNumber(ch))
            return;

        GameData.gridHeight = int.Parse(heightField.text);
        heightLabel.text = GameData.gridHeight.ToString();

        heightField.text = "";
    }

    /**
     * Helper function, returns whether parameter array is valid 
     * @param char array to be checked
     * 
     * @return bool indicating whether array parameter contains a valid number
     * */
    private bool IsNumber(char[] array) {

        char[] numbers = "0123456789".ToCharArray();

        // if empty array
        if (array.Length == 0)
            return false;

        // if first number in the field is 0, 0 is not valid for width
        if (array[0] == numbers[0])
        {
            return false;
        }

        int numberCount = 0;
        //sanity check, all chars must be numbers
        for (int i = 0; i < array.Length; i++)
        {
            char c = array[i];
            // check if current char is any of 1,2,3 ... 9
            for (int j = 0; j < numbers.Length; j++)
            {
                // if char is a number
                if (c == numbers[j])
                {
                    numberCount++;
                    continue;
                }
            }
        }
        // if all char in array are numbers
        return numberCount == array.Length;
    }
}
