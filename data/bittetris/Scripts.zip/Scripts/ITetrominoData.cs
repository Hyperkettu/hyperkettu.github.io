﻿using UnityEngine;
using System.Collections;

/**
 * Tetromino I related data
 * */
public class ITetrominoData : TetrominoData {

        public ITetrominoData() {
            this.numberOfRotations = 2;
            SetOffsetsOfBlocks();
            InitIndicesToBlocks();
    }

    public override void SetOffsetsOfBlocks() {

        // initialize arrays
        offsets = new Vector2[this.numberOfRotations][];

        for (int i = 0; i < offsets.Length; i++)
        {
            offsets[i] = new Vector2[3];
        }
        // first rotation
        offsets[0][0] = new Vector2(-1, 0);
        offsets[0][1] = new Vector2(1, 0);
        offsets[0][2] = new Vector2(2, 0);

        // second rotation
        offsets[1][0] = new Vector2(0, 1);
        offsets[1][1] = new Vector2(0, -1);
        offsets[1][2] = new Vector2(0, -2);
    }

    public override void InitIndicesToBlocks()
    {

        // initialize right indices
        indexToBlockToCheckRight = new int[this.numberOfRotations][];

        // first rotation indices to check when moving right
        indexToBlockToCheckRight[0] = new int[1];
        indexToBlockToCheckRight[0][0] = 3;

        // second rotation indices to check when moving right
        indexToBlockToCheckRight[1] = new int[4];

        // all four blocks have to be checked with I tetromino on second rotation
        for (int i = 0; i < indexToBlockToCheckRight[1].Length; i++)
        {
            indexToBlockToCheckRight[1][i] = i;
        }

        // initialize left indices
        indexToBlockToCheckLeft = new int[this.numberOfRotations][];

        // first rotation indices to check when moving left
        indexToBlockToCheckLeft[0] = new int[1];
        indexToBlockToCheckLeft[0][0] = 1;

        // second rotation indices to check when moving right
        indexToBlockToCheckLeft[1] = new int[4];

        // all four blocks have to be checked with I tetromino on second rotation
        for (int i = 0; i < indexToBlockToCheckLeft[1].Length; i++)
        {
            indexToBlockToCheckLeft[1][i] = i;
        }

        // initialize indices to blocks that have to be checked when moving down
        indexToBlockToCheckDown = new int[this.numberOfRotations][];

        // first rotation indices to check
        indexToBlockToCheckDown[0] = new int[4];

        for (int i = 0; i < 4; i++)
        {
            indexToBlockToCheckDown[0][i] = i;
        }

        // second rotation indices
        indexToBlockToCheckDown[1] = new int[1];
        indexToBlockToCheckDown[1][0] = 3;

    }

}
