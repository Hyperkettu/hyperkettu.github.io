﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TetrisUIController : MonoBehaviour {

    public GameObject gameOverTextPrefab; // over over text prefab

    public Timer timer; // timer
	public Eviltimer evilTimer; // evil timer
    public Text bestScore; // best score label
    public Text currentScore; // current score label

    public AudioClip clickClip; // sound for button click
    public AudioClip gameMusic; // music for this game

    public Camera camera; // current camera

    private AudioSource audio; // audio source

    // initialize
    void Start() {
        audio = GetComponent<AudioSource>();
    }

	/**
	 * Returns time of the evil timer
	 * 
	 * @return time to wait in evil timer
	 * */
	public int GetTimeInEviTimer(){
		return evilTimer.GetTimeToWait ();
	}

    /**
     * Plays button click sound and changes to main menu after clikc audio clip has finished
     * */
    public void ToMenu() {
        // play click sounds
        audio.clip = clickClip;
        audio.Play();
        // change to main menu
        StartCoroutine("ChangeToMainMenu");
    }

    /**
     * Restarts game after click audio clip has finished
     * */
    public void Restart() {
        // play click sounds
        audio.clip = clickClip;
        audio.Play();
        // restart game
        StartCoroutine("RestartThread");
    }

    /**
     *  Changes to main menu after 0.35 seconds (waiting for audio clip to finish)
     *  
     * @return IEnumerator for the thread
     * */
    IEnumerator ChangeToMainMenu() {
        yield return new WaitForSeconds(0.35f);
        ToMainMenu();
    }

    /**
     *  Restart game after 0.35 seconds (waiting for audio clip to finish)
     *  
     * @return IEnumerator for the thread
     * */
    IEnumerator RestartThread()
    {
        yield return new WaitForSeconds(0.35f);
        RestartGame();
    }

    /**
     * This function loads the main menu
     * */
    public void ToMainMenu() {
        SceneManager.LoadScene("Scenes/mainmenu");
    }

    /**
     * Restarts the tetris game
     * */
    public void RestartGame() {
        SceneManager.LoadScene("Scenes/tetris");
    }

    /**
     *  Shows the game over text
     * */
    public void ShowGameOverText() {
        Instantiate(gameOverTextPrefab, new Vector3(0, 0, 10 + camera.transform.position.z), Quaternion.identity);
    
    }

    /**
    * Updates the best score label
    * */
    public void UpdateBestScore()
    {
        bestScore.text = "Best Score: " + GameData.highestScore;
    }

    /**
     * Updates the best score label
     * */
    public void UpdateCurrentScore()
    {
        currentScore.text = "Current Score: " + GameData.currentScore;
    }

    /**
     * Stops timer
     * */ 
    public void StopTimer() {
        timer.StopTimer();
    }

    /**
     *  Starts timer
     * */
    public void StartTimer()
    {
        timer.StartTimer();
    }

    /**
     * Resets timer
     * */
    public void ResetTimer() {
        timer.Reset();
    }

	/**
	 * Starts countdown in eviltimer
	 * */
	public void EviTimerStart(){
		evilTimer.Reset ();
	}
}
