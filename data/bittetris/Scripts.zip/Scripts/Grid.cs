﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

using System.IO;

public class Grid : MonoBehaviour {

    public static float blockDimension = 0.5f; // width of one block

    public int width; // width of the grid
    public int height; // height of the grid

    public GameObject backgroundSquare; // prefab to instantiating visual grid, the grid background
    public GameObject edgeSquare; // prefab to instantiating grid edges (green)
    public GameObject tetrominoPrefab; // prefab to instantiating tetromino
	public GameObject stonePrefab;
	public ParticleSystem explosion;
	public ParticleSystem bless;
	public Sprite appleSprite;

    public AudioClip hitClip; // audio clip for placing blocks to play field
    public AudioClip smashClip; // audio clip for removing rows
    public AudioClip gameOverClip; // game over sound
    public AudioClip evilminoExplosion; // explosion sound for evil mino
    public AudioClip evilminoRattle; // evilmino rattle
    public AudioClip flaw;

    public bool isMenu = false;

    public TetrisUIController uiController; // user interface controller

    public Camera camera; // reference to camera 

    private Tetromino current; // current tetromino that can be controlled with keys
    private Tetromino next; // next tetromino

    private Block[][] grid; // logical grid as multidimensional Block array, null = no block, != null means there is a block
    private int[] maxBlockHeights; // contains the information about the highest block position on the grid

    private bool gameOver = false; // boolean indicating whether game is over
    private bool pause = false; // pause button, used for debugging
    private float waitTime; // time interval for falling blocks (falling speed)

	private List<Block> tempBlocks = new List<Block> ();

    private AudioSource audio; // audio source for playing sounds
	private bool spacePressed = false;
	private bool bigminoFinished = true;

	// Use this for initialization
	void Start () {

        if (!isMenu)
        {

            Screen.orientation = ScreenOrientation.Portrait;

            // set dimensions
            width = 10;
            height = 20;


            // update score labels
            GameData.currentScore = 0;
            UpdateBestScore();
            UpdateCurrentScore();

            // generate grid
            CreateVisualGrid();
            InitializeLogicalGrid();

            // init max block array
            maxBlockHeights = new int[width];

            // start game with creating a falling tetromino
            waitTime = 0.5f;
            CreateRandomTetromino();

            // reset timer
            uiController.ResetTimer();
            uiController.StartTimer();

            audio = GetComponent<AudioSource>();

        }
        
	}
	
	// Update is called once per frame
	void Update () {

        if (current == null)
            return;

		if(Input.GetMouseButtonDown(0)){

			Vector3 mousePos = Input.mousePosition;

			if (mousePos.x < Screen.width / 3.0f) {
				if (CanBeMovedLeft () && bigminoFinished)
					current.MoveLeft ();
			} else if (mousePos.x > 2.0f * Screen.width / 3.0f) {

				if (CanBeMovedRight () && bigminoFinished)
					current.moveRight ();

			} else {
				// x coordinate is in the middle

				if (mousePos.y > Screen.height * 2.0f / 3.0f) {

					if (CanBeRotated ())
						current.Rotate ();
				} else if (mousePos.y < Screen.height / 3.0f) {
					if(!spacePressed && bigminoFinished)
						DropTetrominoDown ();
				} else {
					// in the middle
					if (CanBeMovedDown() && bigminoFinished)
						current.MoveDown();
					else
						PlaceNewBlocksToBoard();
				}
			}


		}

		// if touched
		if (Input.touchCount > 0 && Input.GetTouch (0).phase == TouchPhase.Began && Input.GetTouch(0).deltaTime > 0.14f) {
		
			Vector2 touchPos = Input.GetTouch(0).position;

			if (touchPos.x < Screen.width / 3.0f) {
				if (CanBeMovedLeft () && bigminoFinished)
					current.MoveLeft ();
			} else if (touchPos.x > 2.0f * Screen.width / 3.0f) {

				if (CanBeMovedRight () && bigminoFinished)
					current.moveRight ();

			} else {
				// x coordinate is in the middle

				if (touchPos.y > Screen.height * 2.0f / 3.0f) {

					if (CanBeRotated ())
						current.Rotate ();
				} else if (touchPos.y < Screen.height / 3.0f) {
					if(!spacePressed && bigminoFinished)
						DropTetrominoDown ();
				} else {
					// y coordinate in the middle
					if (CanBeMovedDown() && bigminoFinished)
						current.MoveDown();
					else
						PlaceNewBlocksToBoard();
				}
			}
		
		}

        // up arrowed changes current tetromino rotation if the tetromino can be rotated
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
			if(CanBeRotated() && bigminoFinished)
                current.Rotate();

        } // left arrow moves current tetromino left if there is no obstacle
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
			if(CanBeMovedLeft() && bigminoFinished)
                current.MoveLeft();

        } // down button moves current tetromino right if no obstacle
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
			if(CanBeMovedRight() && bigminoFinished)
                current.moveRight();

        } // moves current tetromino down if no obstacle, otherwise places the tetromino to the play field
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
			if (CanBeMovedDown() && bigminoFinished)
                current.MoveDown();
            else
                PlaceNewBlocksToBoard();
        } // space key drops the current tetromino to the play field immediately
        else if (Input.GetKeyDown(KeyCode.Space))
        {
			if(!spacePressed && bigminoFinished)
            	DropTetrominoDown();

        } // P key was used to debugging 
        else if (Input.GetKeyDown(KeyCode.P))
        {
            // if paused, start coroutine again
            if (pause)
            {
                StartCoroutine("MoveLogic");
            }
            else // if not paused, stop coroutine
            {
                StopCoroutine("MoveLogic");
            }
            // change pause state
            pause = !pause;
        }
        // H key was used for debugging
        else if (Input.GetKeyDown(KeyCode.H))
        {
            // prints the maxBlockHeight array
            string s = "";

            for (int i = 0; i < width; i++)
            {
                s = s + maxBlockHeights[i] + " ";
            }
            Debug.Log(s);
        }
	}

	/**
	 * Writes a highscore to a file named "myFile.txt"
	 * */
	public void WriteNewHighscoreToFile(){

		string file = Application.persistentDataPath + "/myFile.txt";

		StreamWriter sw = File.CreateText (file);
		sw.WriteLine ("" + GameData.highestScore);
		sw.Close ();
	}


    /**
     * This thread shakes the camera
     * 
     * @return IEnumerator for this thread
     * */
    public IEnumerator ShakeCameraThread() { 
    
        int locations = 7;
        float maxDistance = 0.7f;
        float minDistance = 0.2f;

        Vector3 initialPosition = camera.transform.position;
        Vector3[] locs = new Vector3[locations + 1];

        // define some offsets
        for (int i = 0; i < locations; i++)
        {
            float radius = Random.Range(minDistance, maxDistance);
            Vector2 direction = Random.insideUnitCircle;
            Vector3 target = initialPosition + radius * new Vector3(direction.x, direction.y, 0);
            locs[i] = target;
        }

        locs[locations] = initialPosition;

        float speed = 8.5f;
        int index = 0;

        while (true)
        {
            // move camera towards a target position
           camera.transform.position = Vector3.MoveTowards(camera.transform.position, locs[index], speed * Time.deltaTime);

            // if camera is close enough a target, switch to next target
            if((camera.transform.position-locs[index]).magnitude < 0.001f){
                index++;

                // if all targets reached already, quit the thread
                if (index == locations + 1)
                    break;
            }

            yield return new WaitForSeconds(0.01f);

        }
        // set back to initial position
        camera.transform.position = initialPosition;
    }

    /**
     * This function determines whether a world point is seen from camera
     * 
     * @param camera who is watching
     * @param point in world
     * @return boolean indicating whether a camera can see the point
     * */
    bool InfiniteCameraCanSeePoint(Camera camera, Vector3 point)
    {
        Vector3 viewportPoint = camera.WorldToViewportPoint(point);
        return (viewportPoint.z > 0 && (new Rect(0, 0, 1, 1)).Contains(viewportPoint));
    }

    /**
     * Moves the camera to a negative z direction as long as the whole play field grid can be seen from camera
     * */
    void MoveCameraBackwardsToSeeTheWholeGrid() {

        // instantiate top right corner
        GameObject topRight = CreateGameObject(width + 1, height + 1);
        GameObject bottomLeft = CreateGameObject(-10,  -2);

        // move camera back as long as the whole play field can be seen
        bool wholeGridCanBeSeen;
        do
        {
            wholeGridCanBeSeen = InfiniteCameraCanSeePoint(camera, topRight.transform.position);
            wholeGridCanBeSeen &= InfiniteCameraCanSeePoint(camera, bottomLeft.transform.position);
            // move camera to negative z axis direction
            Vector3 position = camera.transform.position;
            position.z -= 0.1f;
            camera.transform.position = position;

        } while (!wholeGridCanBeSeen);
			
    }

    /**
     * Helper function to creating a reference object used to determine whether the camera can seen whole play field
     * 
     * @param x coordinate
     * @param y coordinate
     * @return game object
     * */
    GameObject CreateGameObject(int x, int y) {
        GameObject go = new GameObject();
        go.transform.parent = transform;
        Vector3 pos = new Vector2(x * Grid.blockDimension + Grid.blockDimension / 2.0f, y * Grid.blockDimension + Grid.blockDimension / 2.0f);
        go.transform.localPosition = pos;
        return go;
    }


    /**
     * Updates the best score label
     * */
    public void UpdateBestScore() {
        uiController.UpdateBestScore();
    }

    /**
     * Updates the best score label
     * */
    public void UpdateCurrentScore(){
        uiController.UpdateCurrentScore();
    }

    /**
     * Removes the row specified with y coordinate
     * 
     * @param y coordinate for the row to be removed
     * */
    public void RemoveRow(int y) { 
        for (int i = 0; i < width; i++)
        {
            // it is assumed that block is not null since we are removing a row that was full (used after ShouldRemoveRow() that guarantees that a row is full)
            Block block = grid[y][i];
            block.removeFlag = true;
        }
       
    }

    /**
     * This function checks if a row specified by y coordinate should be removed, ie there is a block in every coordinate of the row
     * 
     * @param y coordinate of the row to check for removal
     * @return bool indicating whether this row should be removed
     * */
    public bool ShouldRemoveRow(int y) {
        // check if there is a block in every column in a row
        for (int i = 0; i < width; i++)
        {
            // if any square is empty or stone, there is no full row
			if (grid[y][i] == null || grid[y][i].type == Block.BlockType.Stone)
                return false;
        }

        // otherwise the row can be removed
        return true;
    }

    /**
     *  This function moves rows downwards by number of removed rows
     *  
     * */
    public void MoveBlocksDownwards(int startY)
    {

        List<Block> blocks = new List<Block>();

        // for each column
        for (int i = 0; i < width; i++)
        {

            int maxHeight = maxBlockHeights[i];

            // handle one column
            for (int j = startY; j < maxHeight; j++)
            {

                Block block = grid[j][i];

                // grid coordinate contains either a removable block or staying block
                if (block != null)
                {
                    // remove block
                    if (block.removeFlag)
                    {
                        Destroy(block.gameObject);
                        grid[j][i] = null;
                    }
                    else { // add to list
                        blocks.Add(block);
                        grid[j][i] = null;
                    }

                }
                else { // block is null (ie empty square)
                    blocks.Add(block);
                    grid[j][i] = null;
                }

                // update max height of column
                maxBlockHeights[i] = startY + blocks.Count;

                // if there are no blocks above the removed rows it is possible that maxBlocksHeights has too a high value
                if (blocks.Count == 0)
                {
                    int index = startY - 1;

                    // move down while we are inside the grid and there are empty squares (ie coordinate is null) 
                    while (index != -1 && grid[index][i] == null)
                    {
                        index--;
                    }
                    // update max height column
                    maxBlockHeights[i] = index + 1;
                 
                }
                

            }

            // all blocks and empty squares collected for this row, so place them back to column but to a lower position
            for (int index = 0; index < blocks.Count; index++)
            {
                int yPosition = startY + index;
                Block bl = blocks[index];
                grid[yPosition][i] = bl;

                if (bl != null)
                    bl.SetLocation(i, yPosition);

            }
            // reinitialize values for next column
            blocks.Clear();
        }

    }


    /**
     *  Drops the current tetromino straight to the play field
     *  */
    public void DropTetrominoDown() {

        // do nothing if game is over
        if (current == null)
            return;

        int maxY = 0; 

        // find max y value for based on the tetromino position and maxBlockHeights array
        for (int i = 0; i < 4; i++) {
            Block block = current.GetBlock(i);
            if (maxBlockHeights[(int)block.position.x] > maxY) {
                maxY = maxBlockHeights[(int) block.position.x];
            }
        }
       
        // move tetromino close to the current max value of the column
       // if(current.y >= maxY)
        //    current.SetPositionY(maxY);
        // stop moving the tetromino since it is placed on the play field
        StopCoroutine("MoveLogic");

        // move tetromino back upwards while the tetromino overlaps play field edges or blocks on the grid, otherwise move downwards as long as possible
        if (!FindSuitablePositionAbove())
            FindSuitablePositionBelow();

        // now that we have found a suitable position in the grid, place the tetromino on the play field
        PlaceNewBlocksToBoard();
    }

    /**
     * Creates a random tetromino above the grid
     */
    public void CreateRandomTetromino() {

        // specify initial spawn position coordinates
        int y = this.height - 1;
        int x = this.width / 2 - 1;

        // if there is no next tetromino create it
        if (next == null) {

            int randomNumber = Random.Range(0, (int)Tetromino.Type.NumTetrominos);

            // instantiate the tetromino
            GameObject go = Instantiate(tetrominoPrefab, Vector3.zero, Quaternion.identity) as GameObject;
            next = go.GetComponent<Tetromino>();
            // initialize values of the tetromino
            next.CreateTetromino(randomNumber, x, y, this);
        }

        // set next tetromino as current
        current = next;
        current.x = x;
        current.SetPositionY(y);
        // animate color
        current.AnimateTetrominoColor();

        // since the grid can be full of blocks the start position might have to be moved upwards
        FindSuitablePositionAbove();

        // if we had to move the created tetromino upwards, we have to check if the tetromino is now out of the play field and the game is thus over
        if (CheckForGameOver(current.y)) {

			gameOver = true;

            // play game over sound
            audio.clip = gameOverClip;
            audio.Play();
            // show game over text
            uiController.ShowGameOverText();

            // stop timer
            uiController.StopTimer();

            // update highest score if we have a new record
            if (GameData.currentScore > GameData.highestScore) {
                GameData.highestScore = GameData.currentScore;
                UpdateBestScore();
				WriteNewHighscoreToFile ();
            }

            // destroy all blocks outside the play field or overlapping other blocks
            for (int i = 0; i < 4; i++) {
                Block block = current.GetBlock(i);
                if(current.GetBlock(i).position.y >= height || grid[(int)block.position.y][(int)block.position.x] != null)
                    Destroy(block.gameObject);
            }

            // destroy tetromino
            Destroy(current.gameObject);
            return;
        }
        

        // start the coroutine to move the current tetromino down
        StartCoroutine("MoveLogic"); 

        // create next tetromino
        int randNumber = Random.Range(0, (int)Tetromino.Type.NumTetrominos);

        // instantiate the tetromino
        GameObject nextGo = Instantiate(tetrominoPrefab, Vector3.zero, Quaternion.identity) as GameObject;
        next = nextGo.GetComponent<Tetromino>();
        // initialize values of the tetromino
        next.CreateTetromino(randNumber, -5, y, this);

		spacePressed = false;
    }

    /**
     *  This function checks if the current tetromino's blocks overlap other blocks in the grid or the tetromino blocks
     *  are outside the play field. False is also returned if the game is over since this function is used with tetromino moving function
     *  and there is no reason moving the tetromino anymore is game is over.
     *  
     * @return boolean indicating tetromino whether the tetromino position is acceptable
     * */
    public bool TetrominoOverlapsBlocks() {

        for (int i = 0; i < 4; i++) {
            Block block = current.GetBlock(i);

            if (CheckForGameOver((int) block.position.y))
                return false;

            // if block is out of the grid from the down side
            if (block.position.y < 0) {
                return true;
            }

            if (grid[(int)block.position.y][(int)block.position.x] != null)
                return true;
        }

        return false;
    }

    /**
     * This function moves current tetromino upwards as long as we have an acceptable position
     * 
     * @return boolean value indicating whether the block was moved upwards
     * */

    public bool FindSuitablePositionAbove() {

        bool movedUp = false;

        // move tetromino upwards while it overlaps blocks which is not allowed
        while (TetrominoOverlapsBlocks()) {
            current.Move(0, 1);
            movedUp = true;
        }

        return movedUp;
    }

    /**
     * This function moves current tetromino downwards as long as it can be moved
     * */

    public void FindSuitablePositionBelow() {
        while (CanBeMovedDown()) {
            current.MoveDown();
        }
    }


    /**
     * This function checks whether the current tetromino can be moved right
     * 
     * @return boolean value indicating if the tetromino can be moved
     * */
    private bool CanBeMovedRight()
    {

        int[] indices = current.GetRightSideIndices();

        int blockX = 0, blockY = 0;

        // check relevant grid coordinates on the right side of the tetromino
        for (int i = 0; i < indices.Length; i++)
        {
            int index = indices[i];
            Block block = current.GetBlock(index);
            blockX = (int) block.position.x + 1;

            // check if tetromino has reached the right edge of the play field
            if (blockX >= this.width)
            {
                return false;
            }
            blockY = (int) block.position.y;

            // block cannot be moved if the block is above the grid
            if (blockY == height)
                return false;

            // if there is a block, tetromino can't be moved right
            if (grid[blockY][blockX] != null) {
                return false;
            }
        }
        return true;
    }


    /**
     * This function checks whether the current tetromino can be moved left
     * 
     * @return boolean value indicating if the tetromino can be moved
     * */
    private bool CanBeMovedLeft()
    {

        int[] indices = current.GetLeftSideIndices();

        int blockX = 0, blockY = 0;

        // check relevant grid coordinates
        for (int i = 0; i < indices.Length; i++)
        {
            int index = indices[i];
            Block block = current.GetBlock(index);
            blockX = (int) block.position.x - 1;
            // check if tetromino has reached the left edge of the play field
            if (blockX < 0)
            {
                return false;
            }
            blockY = (int) block.position.y;

            // block cannot be moved if the block is above the grid
            if (blockY == height)
                return false;

            // if there is a block, tetromino can't be moved left
            if (grid[blockY][blockX] != null)
            {
                return false;
            }
        }
        return true;
    }

    /**
     * This function checks whether the current tetromino can be moved down
     * 
     * @return boolean value indicating if the tetromino can be moved
     * */
    private bool CanBeMovedDown()
    {
        if (current == null)
            return false;

        int[] indices = current.GetDownSideIndices();

        int blockX = 0, blockY = 0;

        // check relevant grid coordinates
        for (int i = 0; i < indices.Length; i++)
        {
            int index = indices[i];
            Block block = current.GetBlock(index);
            blockY = (int)block.position.y - 1;
            // check if tetromino has reached the left edge of the play field
            if (blockY < 0)
            {
                return false;
            }
            blockX = (int)block.position.x;

            // if there is a block, tetromino can't be moved left
            if (grid[blockY][blockX] != null)
            {
                return false;
            }
        }
        return true;
    }

    /**
     *  This function checks if the current tetromino can be rotated
     *  
     * @return boolean indicating whether rotation of the tetromino is possible
     * */
    bool CanBeRotated() {

        // get offsets of blocks for the next rotation
        Vector2[] offsets = current.GetRotationOffsetsOfBlocks(1);

        // check that all squares are free and tetromino can thus be rotated
        for (int i = 0; i < offsets.Length; i++) {
            Vector2 offset = offsets[i];
            int blockX = current.x + (int) offset.x;
            int blockY = current.y + (int) offset.y;

            // check if x coordinate is out of bounds
            if (blockX >= this.width || blockX < 0) {
                return false;
            }
            // check if y coordinate if out of bounds
            if (blockY < 0 || blockY >= height) {
                return false;
            }

            // if there is a block in any of the squares, cannot be rotated
            if (grid[blockY][blockX] != null) {
                return false;
            }

        }
        // otherwise rotation is allowed
        return true;
    }

    /**
     *  Function for moving the current tetromino at certain time interval
     *  
     * @return IEnumerator object for the Start/StopCoroutine functions
     * */
    IEnumerator MoveLogic()
    {
        // this loop runs every waitTime seconds while the game is not over
        while (!gameOver)
        { 
            // first wait some time
            yield return new WaitForSeconds(waitTime);
            // move tetromino down if it is possible
            if (CanBeMovedDown())
            {
                current.MoveDown();
            }
            else // cannot be moved down, so place the tetromino to the play field
            {
                PlaceNewBlocksToBoard();   
            }

        }
    }

	/**
	 * Starts a current tetromino shaking thread and explosion
	 * */
	IEnumerator Shake(){

		int locations = 30;
		float maxDistance = 0.15f;
		float minDistance = 0.1f;

        audio.clip = evilminoRattle;
        //audio.Play();
        audio.PlayOneShot(evilminoRattle, 2.0f);

		Block bigBlock = current.getBigBlock ();

		Vector3 initialPosition = bigBlock.transform.position;
		Vector3[] locs = new Vector3[locations + 1];

		// define some offsets
		for (int i = 0; i < locations; i++)
		{
			float radius = Random.Range(minDistance, maxDistance);
			Vector2 direction = Random.insideUnitCircle;
			Vector3 target = initialPosition + radius * new Vector3(direction.x, direction.y, 0);
			locs[i] = target;
		}

		locs[locations] = initialPosition;

		float speed = 10.5f;
		int index = 0;

		while (true)
		{
			if (bigBlock != null) {
				// move camera towards a target position
				bigBlock.transform.position = Vector3.MoveTowards (bigBlock.transform.position, locs [index], speed * Time.deltaTime);

				// if camera is close enough a target, switch to next target
				if ((bigBlock.transform.position - locs [index]).magnitude < 0.001f) {
					index++;

					// if all targets reached already, quit the thread
					if (index == locations + 1)
						break;
				}

				yield return new WaitForSeconds (0.01f);
			}
		}

		if (bigBlock != null) {
			// set back to initial position
			bigBlock.transform.position = initialPosition;
		

			// starts explosion
			Instantiate (explosion, bigBlock.transform.position, Quaternion.identity);
            audio.PlayOneShot(evilminoExplosion, 2.0f);
		}
		// create stones
		for (int i = 0; i < 4; i++) {

			Block block = current.GetBlock (i);
			int x = (int)block.position.x;
			int y = (int)block.position.y;

			tempBlocks.Add(CreateStone (x, y));
		} 

		Block block2 = current.GetBlock(0);
		int x2 = (int) block2.position.x;
		int y2 = (int) block2.position.y;

		Vector2[] positions = new Vector2[] {new Vector2 (x2, y2 + 1), new Vector2 (x2 + 1, y2 + 1),
			new Vector2 (x2 - 1, y2), new Vector2 (x2 - 1, y2 - 1),
			new Vector2 (x2 + 2, y2), new Vector2 (x2 + 2, y2 - 1),
			new Vector2 (x2, y2 - 2), new Vector2 (x2 + 1, y2 - 2)
		};

		for (int i = 0; i < positions.Length; i++) {

			int x = (int)positions [i].x;
			int y = (int)positions [i].y;
			Block tempBlock = CreateStone (x, y);

			if(tempBlock != null)
				tempBlocks.Add(tempBlock);	
		}

		// destory current tetromino
		Destroy (current.gameObject);
		Destroy (current.getBigBlock ().gameObject);

		if (!gameOver)
			CreateRandomTetromino ();

		bigminoFinished = true;

		StartCoroutine ("FadeOutStones");
	}

	/**
	 * This fades out all stones of a certain evilmino
	 * */
	IEnumerator FadeOutStones(){

		List<Block> blocks = new List<Block> (tempBlocks);
		tempBlocks.Clear ();

		// start evil timer and wait for one minute it to complete
		uiController.EviTimerStart ();
		yield return new WaitForSeconds (uiController.GetTimeInEviTimer());

		Color initialColor = Color.white;
		Color color;

		for (int i = 0; i < blocks.Count; i++) {
			if (blocks [i] != null) {
				SpriteRenderer sr = blocks[i].GetComponent<SpriteRenderer>();
				initialColor = sr.color;
				break;
			}
		}

		while (true) {

			float t = Mathf.PingPong(Time.time, 2.0f) / 2.0f;
			color = Color.Lerp(initialColor, Color.clear, t);

			// change color for each stone
			for (int i = 0; i < blocks.Count; i++) {
				// if the block is still there
				if (blocks [i] != null) {
					SpriteRenderer sp = blocks [i].GetComponent<SpriteRenderer> ();
					sp.color = color;
				}
			}

			if ((color - Color.clear).grayscale < 0.1f)
				break;

			yield return new WaitForSeconds (0.1f);
		}

		// destroy all stones
		for (int i = 0; i < blocks.Count; i++) {

			Block block = blocks [i];

			if (block != null) {
				int x = (int)block.position.x;
				int y = (int)block.position.y;

				Destroy (block.gameObject);

				// empty square only if current block is still there
				if (block == grid [y] [x])
					grid [y] [x] = null;

				Destroy (block.gameObject);
			}
		}
	}

	/**
     * Helper function to creating a reference object used to determine whether the camera can seen whole play field
     * 
     * @param x coordinate
     * @param y coordinate
     * @return game object
     * */
	Block CreateStone(int x, int y) {

		// if creatable stone is outside play field, do not create
		if (x < 0 || x > width - 1 || y < 0 || y > height - 1) {
			return null;
		}

		// if not empty and is stone
		if (grid [y] [x] != null && grid [y] [x].type == Block.BlockType.Stone) {
			return null; 

		} else { // not stone or empty

			// create new stone
			GameObject go = (GameObject)Instantiate (stonePrefab);
			go.transform.parent = transform;
			Vector3 pos = new Vector2(x * Grid.blockDimension + Grid.blockDimension / 2.0f, y * Grid.blockDimension + Grid.blockDimension / 2.0f);
			go.transform.localPosition = pos;

			Block bl = go.GetComponent<Block>();

			// if not empty, destroy previous
			if(grid [y] [x] != null)
				Destroy (grid [y] [x].gameObject);
			grid [y] [x] = bl;

			return bl;
		}
	}

	/**
	 * Destory is kind of a misleading name since, this function determines whether this block
	 * in x, y coordinates can be destroyed
	 * 
	 * @param x Coordinate x
	 * @param y Coordinate y
	 * @return null if can not be destroyed, otherwise the block
	 * */
	public Block Destroy(int x, int y){

		// if out of play field, do nothing
		if (y < 0)
			return null;

		// if square is empty, do nothing
		if (grid [y] [x] == null)
			return null;

		Block block = grid [y] [x];

		Color color = new Color (1.0f, 1.0f, 1.0f, 1.0f);
		block.gameObject.GetComponent<SpriteRenderer> ().sprite = appleSprite;
		block.SetColor (color);

		return block;
	
	}

	/**
	 * Sends certain block to be destroyed
	 * */
	public void DestroyField(){

        if (!bigminoFinished)
            return;

		List<Block> blocks = new List<Block> ();

		Block block = current.GetBlock(0);
		int x = (int) block.position.x;
		int y = (int) block.position.y;

		for (int i = x; i < x + 2; i++) {
			for (int j = y - 2; j > y - 5; j--) {
				Block bl = Destroy (i, j);

				// if there was a block
				if(bl != null){
					blocks.Add (bl);
				}
			}
		}

        bigminoFinished = false;
		StartCoroutine (FadeOutBlocks (blocks));
        
	}

	/**
	 * Fade out all holy blocks and destroy them in the end
	 * */
	IEnumerator FadeOutBlocks(List<Block> blocks){

		Instantiate (bless, current.getBigBlock().transform.position, Quaternion.identity);
        audio.clip = flaw;
        audio.Play();

		yield return new WaitForSeconds (3.0f);

        // destory current tetromino

        if (current!= null)
        {
            if(current.getBigBlock() != null)
                Destroy(current.getBigBlock().gameObject);
            
            Destroy(current.gameObject);
        }

		Color currentColor = Color.white;

		int blockCount = blocks.Count;

		float fadeSpeed = 10.0f; 

		while (true) {

			//float t = Mathf.PingPong (Time.time, 2.0f) / 2.0f;

            int blockCounter = 0;

			for (int i = 0; i < blocks.Count; i++) {

				Block block = blocks [i];

                if (block == null)
                    continue;

                blockCounter++;

                currentColor = block.GetColor();
                currentColor = Color.Lerp(currentColor, Color.clear, fadeSpeed * Time.deltaTime);
                
				//color = Color.Lerp (Color.white, Color.clear, t);

			    block.SetColor (currentColor);
			}
            // if not anymore blocks
            if (blockCounter == 0)
                break;

			if (currentColor.grayscale < 0.1f)
				break;

			yield return new WaitForSeconds (0.1f);
		}

		// destroy block nullify grid
		for(int i = 0; i < blocks.Count; i++){

			Block block = blocks [i];
			if (block != null) {
				int x = (int)block.position.x;
				int y = (int)block.position.y;
				grid [y] [x] = null;
				Destroy (block.gameObject);
			}
		}

		if (!gameOver) {
			GameData.currentScore += blockCount * 50;
			uiController.UpdateCurrentScore ();

            CreateRandomTetromino ();
		}

        bigminoFinished = true;
	}

    /**
     * This function places the new blocks to the play field and does certain tasks such as checking removable rows, moving blocks downwards, calculating points etc.
     * */
    public void PlaceNewBlocksToBoard() {

        // if there is no current tetromino do nothing (due to game over)
        if (current == null)
            return;

        // stop the block moving coroutine
        StopCoroutine("MoveLogic");

		// if current tetromino is big
		if ((int)current.tetroType > 6) {

			if (current.tetroType == Tetromino.Type.Evilmino) {
				bigminoFinished = false;
				StartCoroutine ("Shake");
			}
			else if (current.tetroType == Tetromino.Type.Goodmino) {
				DestroyField ();

                //// destory current tetromino
                //Destroy(current.getBigBlock().gameObject);
                //Destroy(current.gameObject);

                //if (!gameOver)
                //    CreateRandomTetromino ();
			}
		
		} else {

			int maxY = -1;
			int minY = height;

			// place blocks of the current tetromino to the board
			for (int i = 0; i < 4; i++) {
            
				Block block = current.GetBlock (i);
				int blockY = (int)block.position.y;
				// check for game over condition
				if (CheckForGameOver (blockY)) {
					Debug.Log ("game over1");
					gameOver = true;
					// play game over sound
					audio.clip = gameOverClip;
					audio.Play ();
					continue;
				}
				int blockX = (int)block.position.x;
				grid [blockY] [blockX] = block;

				// find max y coordinate
				if (blockY > maxY) {
					maxY = blockY;
				}

				// find min y coordinate 
				if (blockY < minY) {
					minY = blockY;
				}

				// update information on maxBlocksHeight if we have a higher value
				if (maxBlockHeights [blockX] < blockY + 1)
					maxBlockHeights [blockX] = blockY + 1;
			}

			// play hit sound 
			audio.clip = hitClip;
			audio.Play ();

			int numberOfRemovedRows = 0;

			int minRemovedRow = height;

			// check all potential rows for removal
			for (int i = minY; i <= maxY; i++) {

				// if row should be removed, removed it and fill rows array and increase number of removed rows
				if (ShouldRemoveRow (i)) {
					RemoveRow (i);
					numberOfRemovedRows++;

					// find a removed row with a smallest y coordinate
					if (i < minRemovedRow)
						minRemovedRow = i;
				}
        
			}

			// give points according to some specified rule if removed rows exist
			if (numberOfRemovedRows > 0) {
				// move blocks downwards according to removed rows
				MoveBlocksDownwards (minRemovedRow);

				// play smash sound
				audio.clip = smashClip;
				audio.Play ();

				// shake camera
				StartCoroutine ("ShakeCameraThread");

				// calculate points
				int points = CalculatePoints (minRemovedRow, numberOfRemovedRows);
				GameData.currentScore += points;
				// update score label
				UpdateCurrentScore ();
			}

			// destroy current tetromino
			Destroy (current.gameObject);

			if (!gameOver)
				CreateRandomTetromino ();
		}
    }

    int CalculatePoints(int level, int numberOfRemovedRows) { 
        // give more points if more removed rows and depending on how high the removed rows are in the play field
        return (int)(Mathf.Pow(2, numberOfRemovedRows) * (level+1) * 10);
    }

    /**
     *  Initializes the logical grid with nulls
     * */
    public void InitializeLogicalGrid() {
        grid = new Block[height][];

        for (int i = 0; i < grid.Length; i++) {
            grid[i] = new Block[width];
        }
    }

    
    /**
     *  Checks the game over condition. The game is over is the parameter y is higher or equal to height variable
     *  
     *  @param y coordinate
     *  @return bool indicating whether the game is over
     * */
    public bool CheckForGameOver(int y) {
        return y >= height;
    }


    /**
     *  Creates the grid from sprites
     * */
    public void CreateVisualGrid()
    {
        // create dark grid with background square sprites
        for (int j = 0; j < height; j++)
        {
            for (int i = 0; i < width; i++)
            {
                Vector3 pos = new Vector2(i * blockDimension + blockDimension / 2.0f, j * blockDimension + blockDimension / 2.0f);
                GameObject go = (GameObject)Instantiate(backgroundSquare, pos, Quaternion.identity);
                go.transform.parent = transform;

            }
        }

        // create green edges to the left and right side of the grid with edge square sprites 
        for (int j = 0; j < height; j++)
        {
            Vector3 pos = new Vector2(-blockDimension / 2.0f, j * blockDimension + blockDimension / 2.0f);
            GameObject go = (GameObject)Instantiate(edgeSquare, pos, Quaternion.identity);
            go.transform.parent = transform;

            pos = new Vector2(width * blockDimension + blockDimension / 2.0f, j * blockDimension + blockDimension / 2.0f);
            go = (GameObject)Instantiate(edgeSquare, pos, Quaternion.identity);
            go.transform.parent = transform;
        }

        // create green edge under the grid with edge square sprites
        for (int i = -1; i < width + 1; i++)
        {
            Vector3 pos = new Vector2(i * blockDimension + blockDimension / 2.0f, -blockDimension / 2.0f);
            GameObject go = (GameObject)Instantiate(edgeSquare, pos, Quaternion.identity);
            go.transform.parent = transform;
        }

        transform.position -= new Vector3(((float)(width / 2.0f)) * blockDimension, 4.5f);
    
    }
}
