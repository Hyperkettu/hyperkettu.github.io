﻿using UnityEngine;
using System.Collections;

using System.Collections.Generic;

public class BlockDropper : MonoBehaviour {

    public GameObject tetrominoPrefab; // instancing menu tetrominos

    private List<Tetromino> tetrominos = new List<Tetromino>();

	// Use this for initialization
	void Start () {

        CreateTetrominos();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    /**
     * Creates 15 random tetrominos with random time
     * */
    public void CreateTetrominos() {

        float sumDelay = 0.0f;

        for (int i = 0; i < 10; i++)
        {
            float delay = Random.Range(3.0f, 10.0f);
            sumDelay += delay;
            Invoke("CreateRandomTetromino", sumDelay);
        }

        // start the coroutine to move the current tetromino down
        StartCoroutine("MoveLogic");
    }

    /**
     * Creates a random tetromino above the grid
     */
    public void CreateRandomTetromino()
    {

        // specify initial spawn position coordinates
        int y = 15;
        int x = Random.Range(-20, 20);


        int randomNumber = Random.Range(0, (int)Tetromino.Type.NumTetrominos);

        Tetromino next;

        // instantiate the tetromino
        GameObject go = Instantiate(tetrominoPrefab, Vector3.zero, Quaternion.identity) as GameObject;
        next = go.GetComponent<Tetromino>();
        // initialize values of the tetromino

        Grid grid = GetComponent<Grid>();

        next.CreateTetromino(randomNumber, x, y, grid);

        tetrominos.Add(next);

    }

    /**
     * Thread for moving tetrominos in the main menu
     * */
    IEnumerator MoveLogic()
    {

        while (true)
        {
            for (int i = 0; i < tetrominos.Count; i++) {
                Tetromino current = tetrominos[i];
                tetrominos[i].MoveDown();

                if (tetrominos[i].y < -20) {
                    current.x = Random.Range(-20, 20);
                    current.SetPositionY(20);

                    Color randomColor = Block.RandomColor();

                    if ((int)current.tetroType < 7){

                        for (int j = 0; j < 4; j++)
                        {
                            current.GetBlock(j).SetColor(randomColor);
                        }
                    }
                    else
                        current.getBigBlock().SetColor(randomColor);
                }
            }

                yield return new WaitForSeconds(0.5f);
        }

    }
}
