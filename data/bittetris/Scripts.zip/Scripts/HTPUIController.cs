﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class HTPUIController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		// force landcape orientation in this scene
		Screen.orientation = ScreenOrientation.Landscape;
	}

	// Update is called once per frame
	void Update () {
	
	}

	/**
	 * Switch to main menu
	 * */
	public void ToMenu(){
		SceneManager.LoadScene ("scenes/mainmenu");
	}
}
