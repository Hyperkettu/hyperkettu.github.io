﻿using UnityEngine;
using System.Collections;

/**
 * Tetromino Z related data
 * */
public class ZTetrominoData : TetrominoData
{

    public ZTetrominoData()
    {
        this.numberOfRotations = 2;
        SetOffsetsOfBlocks();
        InitIndicesToBlocks();


    }

    public override void SetOffsetsOfBlocks()
    {

        offsets = new Vector2[this.numberOfRotations][];

        for (int i = 0; i < offsets.Length; i++)
        {
            offsets[i] = new Vector2[3];
        }

        // first rotation
        offsets[0][0] = new Vector2(-1, 0);
        offsets[0][1] = new Vector2(0, -1);
        offsets[0][2] = new Vector2(1, -1);

        // second rotation
        offsets[1][0] = new Vector2(1, 1);
        offsets[1][1] = new Vector2(1, 0);
        offsets[1][2] = new Vector2(0, -1);
    }

    public override void InitIndicesToBlocks()
    {
        // RIGHT SIDE INDICES
        indexToBlockToCheckRight = new int[this.numberOfRotations][];

        // first rotation
        indexToBlockToCheckRight[0] = new int[2] { 0, 3 };
        // second rotation
        indexToBlockToCheckRight[1] = new int[3] { 1, 2, 3 };

        // LEFT SIDE INDICES
        indexToBlockToCheckLeft = new int[this.numberOfRotations][];

        // first rotation
        indexToBlockToCheckLeft[0] = new int[2] { 1, 2 };
        // second rotation
        indexToBlockToCheckLeft[1] = new int[3] { 0, 1, 3 };

        // DOWN SIDE INDICES
        indexToBlockToCheckDown = new int[this.numberOfRotations][];

        // first rotation
        indexToBlockToCheckDown[0] = new int[3] { 1, 2, 3 };
        // second rotation
        indexToBlockToCheckDown[1] = new int[2] { 2, 3 };

    }
}
