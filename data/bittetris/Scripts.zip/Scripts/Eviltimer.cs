﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Eviltimer : Timer {

	private int timeToWait;

	// Use this for initialization
	void Start () {
		timerText = GetComponent<Text>();
		timerText.gameObject.SetActive (false);

		timeToWait = 30;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	/**
	 * Returns time to wait for this timer
	 * */
	public int GetTimeToWait(){
		return timeToWait;
	}

	/**
     * Resets the time to time to wait, always resets the timer when new evilminos appear
     * */
	public override void Reset() {

		StopTimer ();
		timeInSeconds = timeToWait;

		timerText.gameObject.SetActive (true);
		UpdateText ();
		StartTimer ();

	}

	/**
     * Starts the timer
     * */
	public override void StartTimer() {
		StartCoroutine("TimerCountdownThread");
	}

	/**
     * Stops the timer
     * */
	public override void StopTimer() {
		StopCoroutine("TimerCountdownThread");
	}

	/**
     * Increments time every second and update text field
     * */
	IEnumerator TimerCountdownThread() {
		while (true) { 
			// wait one second
			yield return new WaitForSeconds(1.0f);
			timeInSeconds--;
			UpdateText();

			if (timeInSeconds == 0)
				break;
		}

		timerText.gameObject.SetActive (false);
	}
}
