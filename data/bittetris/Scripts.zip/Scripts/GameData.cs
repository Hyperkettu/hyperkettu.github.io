﻿using UnityEngine;
using System.Collections;

/**
 * Game specific data
 * */
public class GameData : MonoBehaviour {

    public static int currentScore = 0; // current score 
    public static int highestScore = 0; // highest score all time

    public static int gridWidth = 10; //  grid width
    public static int gridHeight = 20; // grid height

}
