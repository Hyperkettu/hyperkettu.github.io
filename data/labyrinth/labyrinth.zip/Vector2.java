package Geometry;

public class Vector2
{
  public double x,y; 
   
  public Vector2 (double _x, double _y)
  {
    x = _x;
    y = _y;
  }
  
  public Vector2 (Vector2 rhs)
  {
    x = rhs.x;
    y = rhs.y;
  }
  
  public void inc (Vector2 rhs)
  {
    x += rhs.x;
    y += rhs.y;
  }

  public void dec (Vector2 rhs)
  {
    x -= rhs.x;
    y -= rhs.y;
  }
  
  public Vector2 copy ()
  {
    return new Vector2 (x, y);
  }
  
  public Vector2 add (Vector2 rhs)
  {
    return new Vector2(x + rhs.x, y + rhs.y);
  }

  public Vector2 sub (Vector2 rhs)
  {
    return new Vector2(x - rhs.x, y - rhs.y);
  }

  public Vector2 mul (double s)
  {
    return new Vector2 (x*s, y*s);
  }
    
  public Vector2 neg ()
  {
    return new Vector2 (-x, -y);
  }
  
  public Vector2 perp ()
  {
    return new Vector2 (-y, x);
  }

  public double dot (Vector2 rhs)
  {
    return x*rhs.x + y*rhs.y;
  }
  
  public double norm2 ()
  {
    return this.dot(this);
  }
  
  public double norm ()
  {
    return Math.sqrt(norm2());
  }
    
  public double distance2 (Vector2 a)
  {
    return (x - a.x)*(x - a.x) + (y - a.y)*(y - a.y);
  }
  
  public double distance (Vector2 a)
  {
    return Math.sqrt (distance2(a));
  }

  public Vector2 normalized ()
  {
    return mul(1.0/norm());
  }
    
  public double normalize ()
  {
    double n = norm();
    double s = 1.0/n;
    x *= s;
    y *= s;
    return n;
  }    
  
  // 2x2 determinant with this as first row or column.
  public double det (Vector2 rhs)
  {
    return x * rhs.y - rhs.x * y;
  }
} 
