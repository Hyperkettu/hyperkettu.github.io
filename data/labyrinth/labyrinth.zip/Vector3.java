package Geometry;

public class Vector3
{
  public double x,y,z; 
   
  public Vector3 (double _x, double _y, double _z)
  {
    x = _x;
    y = _y;
    z = _z;
  }
  
  public Vector3 (Vector3 rhs)
  {
    x = rhs.x;
    y = rhs.y;
    z = rhs.z;
  }
  
  public void inc (Vector3 rhs)
  {
    x += rhs.x;
    y += rhs.y;
    z += rhs.z;
  }

  public void dec (Vector3 rhs)
  {
    x -= rhs.x;
    y -= rhs.y;
    z -= rhs.z;
  }
  
  public Vector3 copy ()
  {
    return new Vector3 (x, y, z);
  }
  
  public Vector3 add (Vector3 rhs)
  {
    return new Vector3(x + rhs.x, y + rhs.y, z + rhs.z);
  }

  public Vector3 sub (Vector3 rhs)
  {
    return new Vector3(x - rhs.x, y - rhs.y, z - rhs.z);
  }

  public Vector3 mul (double s)
  {
    return new Vector3 (x*s, y*s, z*s);
  }
    
  public Vector3 neg ()
  {
    return new Vector3 (-x, -y, -z);
  }
  
  public double dot (Vector3 rhs)
  {
    return x*rhs.x + y*rhs.y + z*rhs.z;
  }
  
  public double norm2 ()
  {
    return this.dot(this);
  }
  
  public double norm ()
  {
    return Math.sqrt(norm2());
  }
    
  public double distance2 (Vector3 a)
  {
    return (x - a.x)*(x - a.x) + (y - a.y)*(y - a.y) + (z - a.z)*(z - a.z);
  }
  
  public double distance (Vector3 a)
  {
    return Math.sqrt (distance2(a));
  }

  public Vector3 normalized ()
  {
    return mul(1.0/norm());
  }
    
  public double normalize ()
  {
    double n = norm();
    if (n < 1e-12)
      return n;
    double s = 1.0/n;
    x *= s;
    y *= s;
    return n;
  }    
}
