package Geometry;

// 3x3 matrix stored in row major form.
public class Matrix3
{
  public double[] m;
  
  public Matrix3 (double[] _m)
  {
    m = _m;
  }
  
  public Matrix3 (double a00, double a01, double a02,
                  double a10, double a11, double a12,
                  double a20, double a21, double a22)
  {
    m = new double[9];
    m[0] = a00; m[1] = a01; m[2] = a02;
    m[3] = a10; m[4] = a11; m[5] = a12;
    m[6] = a20; m[7] = a21; m[8] = a22;
  }

  public final Matrix3 copy ()
  {
    double[] m2 = new double[9];
    for (int i = 0; i < 9; ++i)
      m2[i] = m[i];
    return new Matrix3(m);  
  }
  
  public final double at (int i, int j)
  {
    return m[3*i+j];
  }
  
  public final void set (int i, int j, double x)
  {
    m[3*i+j] = x;
  }

  public final void inc (Matrix3 B)
  {
    for (int i = 0; i < 9; ++i)
      m[i] += B.m[i];
  }
  
  public final void dec (Matrix3 B)
  {
    for (int i = 0; i < 9; ++i)
      m[i] -= B.m[i];
  }
 
  public final Matrix3 add (Matrix3 B)
  {
    return new Matrix3 ( m[0] + B.m[0], m[1] + B.m[1], m[2] + B.m[2],
                         m[3] + B.m[3], m[4] + B.m[4], m[5] + B.m[5],
                         m[6] + B.m[6], m[7] + B.m[7], m[8] + B.m[8]);
  }
  
  public final Matrix3 sub (Matrix3 B)
  {
    return new Matrix3 ( m[0] - B.m[0], m[1] - B.m[1], m[2] - B.m[2],
                         m[3] - B.m[3], m[4] - B.m[4], m[5] - B.m[5],
                         m[6] - B.m[6], m[7] - B.m[7], m[8] - B.m[8]);
  }
  
  // GAXPY: Generalized AX + Y
  // this <-this + AB
  public final Matrix3 gaxpy (Matrix3 A, Matrix3 B)
  {
    for (int i = 0; i < 3; ++i)
     for (int j = 0; j < 3; ++j)
     {
       double ABij = 0.0;
       for (int k = 0; k < 3; ++k)
         ABij += A.m[3*i+k] * B.m[3*k+j];
       m[3*i+j] += ABij;
     }
    return this;
  }  
  
  public final Matrix3 mul (Matrix3 B)
  {
    return zeros().gaxpy(this, B);
  }  

  public final Matrix3 inv ()
  {
    double a = m[0]; double b = m[1]; double c = m[2];
    double d = m[3]; double e = m[4]; double f = m[5];
    double g = m[6]; double h = m[7]; double i = m[8];    
    double det = a*e*i-a*f*h-d*b*i+d*c*h+g*b*f-g*c*e;
    if (Math.abs(det) < 1d-10) 
      return null; // Singular matrix
    double _det = 1.0 / det;
    return new Matrix3 (_det*( e*i-f*h),  _det*(-b*i+c*h), _det*( b*f-c*e),
                        _det*(-d*i+f*g),  _det*( a*i-c*g), _det*(-a*f+c*d),
                        _det*( d*h-e*g),  _det*(-a*h+b*g), _det*( a*e-b*d));
  }
  
  public final Vector3 row (int i)
  {
    return new Vector3(m[3*i], m[3*i+1], m[3*i+2]);
  }
  
  public final Vector3 col (int i)
  {
    return new Vector3(m[3*i], m[3*i+3], m[3*i+6]);
  }
    
  public final Vector2 map (Vector2 u)
  {
    double a = m[0] * u.x + m[1] * u.y + m[2];
    double b = m[3] * u.x + m[4] * u.y + m[5];
    double c = m[6] * u.x + m[7] * u.y + m[8];    
    double _c = 1.0/c;
    return new Vector2 (_c * a, _c * b);
  }
    
  public static Matrix3 zeros ()
  {
    return new Matrix3 (new double[9]);
  }
    
  public static Matrix3 identity ()
  {
    return new Matrix3 (1.0, 0.0, 0.0,
                        0.0, 1.0, 0.0,
                        0.0, 0.0, 1.0);
  }
  
  public static Matrix3 translate (double dx, double dy)
  {
    return new Matrix3 (1.0, 0.0, dx,
                        0.0, 1.0, dy,
                        0.0, 0.0, 1.0); 
  }
  
  public static Matrix3 rotate (double theta)
  {
    double c = Math.cos (theta);
    double s = Math.sin (theta);
    return new Matrix3 (  c,  -s, 0.0,
                          s,   c, 0.0,
                        0.0, 0.0, 1.0); 
  }
  
  public static Matrix3 rotateX (double theta)
  {
    double c = Math.cos (theta);
    double s = Math.sin (theta);
    return new Matrix3 (1.0, 0.0, 0.0,
                        0.0,   c,  -s,
                        0.0,   s,   c); 
  }

  public static Matrix3 rotateY (double theta)
  {
    double c = Math.cos (theta);
    double s = Math.sin (theta);
    return new Matrix3 (  c, 0.0,   s,
                        0.0, 1.0, 0.0,
                         -s, 0.0,   c); 
  }
  
  public static Matrix3 rotateZ (double theta)
  {
    return rotate (theta);
  }
    
  public static Matrix3 rotateXAxisTo (Vector2 d)
  {
    return new Matrix3 ( d.x, -d.y, 0.0,
                         d.y,  d.x, 0.0,
                         0.0, 0.0, 1.0); 
  }
  
  public static Matrix3 rotateXAxisFrom (Vector2 d)
  {
    return new Matrix3 ( d.x,  d.y, 0.0,
                        -d.y,  d.x, 0.0,
                         0.0, 0.0, 1.0); 
  }

  public static Matrix3 scale (double sx, double sy)
  {
    return new Matrix3 ( sx, 0.0, 0.0,
                        0.0,  sy, 0.0,
                        0.0, 0.0, 1.0); 
  } 
};

