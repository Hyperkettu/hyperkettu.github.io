#ifndef _AABB_H
#define _AABB_H

#include <utility>

#include "vector3.h"

class Ray; ///< forward declaration

/** 
 * This class defines an axis aligned bounding box
 */
class AABB {

public: 

	/**
	 * Default constructor
	 */
	AABB() : bbMin(0,0,0), bbMax(0,0,0){};

	/**
	 * Second constructor
	 * 
	 * @param min
	 * @param max
	 */
	AABB(const Vector3& min, const Vector3& max) : bbMin(min), bbMax(max) {}

	/**
	 * Third constructor
	 *
	 * @param minX
	 * @param minY
	 * @param minZ
	 * @param maxY
	 * @param maxY
	 * @param maxZ
	 */
	AABB(float minX, float minY, float minZ, float maxX, float maxY, float maxZ ) : bbMin(minX, minY, minZ), bbMax(maxX, maxY, maxZ) {}


	/**
	 * Sets the bounds of the AABB
	 *
	 * @param minX
	 * @param minY
	 * @param minZ
	 * @param maxX
	 * @param maxY
	 * @param maxZ
	 */
	void setXYZ(float minX, float minY, float minZ, float maxX, float maxY, float maxZ){
		bbMin.setTo(minX, minY, minZ);
		bbMax.setTo(maxX, maxY, maxZ);
	}

	/**
	* Sets the bounds of the AABB
	*
	* @param min vector
	* @param max vector
	*/
	void setBounds(const Vector3& min, const Vector3& max) {
		bbMin = min;
		bbMax = max;
	}

	/**
	 * Returns the minimum bound
	 *
	 * @return min vector
	 */
	const Vector3& getMin()  const {
		return bbMin;
	}

	/**
	* Returns the maximum bound
	*
	* @return max vector
	*/
	const Vector3& getMax()  const {
		return bbMin;
	}

	/***
	 * Calculates the surface area for this AABB
	 * 
	 * @return area of the box
     */
	float area();

	/***
	 * Calculates the left area of this AABB when 
	 * split plane splits the AABB in the position of
	 * splitPosition on a speciefied axis
	 *
	 * @param axis
	 * @param splitPosition
	 * @return left area
	 */
	float leftArea(unsigned axis, float splitPosition);

	/***
	* Calculates the right area of this AABB when
	* split plane splits the AABB in the position of
	* splitPosition on a speciefied axis
	*
	* @param axis
	* @param splitPosition
	* @return right area
	*/
	float rightArea(unsigned axis, float splitPosition);


	/**
	 * Converts the information of this AABB to a string
	 *
	 * @return string
	 */
	std::string toString() const {
		std::ostringstream os;
		os << "Min: " << bbMin.toString() << ", max: " << bbMax.toString();
		return os.str();
	}

	/***
	 * Checks whether the AABB intersects the plane
	 * 
	 * @param axis (X,Y or Z)
	 * @param planePosition
	 *
	 * @return 
	 * -1 if the AABB is on the negative side of the plane
		0 if the AABB intersects the plane
		1 if the AABB is on the positive side of the plane
	 */
	int intersects(unsigned axis, float planePosition) const{

		if (bbMax[axis] <= planePosition) return -1;
		if (bbMin[axis] >= planePosition) return 1;
		return 0;
	}

	/**
	 * Calculates an intersection between a ray and AABB
	 * If returns an intervall where first is greater than
	 * second, we have an intersection, otherwise not
	 *
	 * @param ray
	 * @return interval
	 */
	std::pair<float, float> intersect(const Ray& ray);

private:

	Vector3 bbMin; ///< minimum bound of the AABB
	Vector3 bbMax; ///< max bound of the AABB

};

#endif