#include "stdafx.h"
#include "model.h"

#include "sse_alignment_freestore_ops.h"

#include <chrono>

enum { X, Y, Z };

Model::Model(const std::string modelFile, bool searchKDTree) :
maxBounds(),
minBounds(),
filename(modelFile),
faces(),
vertexes(),
searchKDTree(searchKDTree),
backfaceCull(true),
frontfaceCull(false) {
    if(modelFile == "") {
        throw;
    }
    Logger::messageStream() << "Model::Model() reading model from " << modelFile << std::endl;
    std::cout << "Reading model from " << modelFile << std::endl;
    std::auto_ptr<PLY_Model> plyModel = Read_PLY_Model(modelFile.c_str());
    std::vector<float> vData = plyModel->m_vertex_data;
    Logger::message("Model::Model() converting model data");
    std::cout <<  "Converting model data... ";
    for(unsigned i = 0; i < vData.size(); i += 3) {
        this->vertexes.push_back(Vector3(vData[i], vData[i + 1], vData[i + 2]));
    }
    std::cout << this->vertexes.size() << " vertexes";
    std::vector<int> fData = plyModel->m_face_data;
	unsigned trianglesRejected = 0;
    for(unsigned i = 0; i < fData.size(); i += 3) {
        this->faces.push_back(Triangle(&(this->vertexes[fData[i]]), 
                &(this->vertexes[fData[i + 1]]), &(this->vertexes[fData[i + 2]])));
		if(this->faces.back().isInvalid()) {
			++trianglesRejected;
			this->faces.popBack();
		}
    }
    std::cout << ", " << this->faces.size() << " triangles created, " << trianglesRejected << " triangles rejected" << std::endl;
    this->maxBounds[X] = plyModel->Get_Bound_Max(X);
    this->maxBounds[Y] = plyModel->Get_Bound_Max(Y);
    this->maxBounds[Z] = plyModel->Get_Bound_Max(Z);
    this->minBounds[X] = plyModel->Get_Bound_Min(X);
    this->minBounds[Y] = plyModel->Get_Bound_Min(Y);
    this->minBounds[Z] = plyModel->Get_Bound_Min(Z);
    Logger::messageStream() << "Model::Model() model data converted: " << toString() << std::endl;
    std::cout << toString() << std::endl;
	if(this->searchKDTree) {
		Logger::messageStream() << "Model::Model() inserting data to KDTree " << std::endl;
		std::cout << "Inserting data to KDTree " << std::endl;
		//TODO FOR ASSIGNMENT: Create nodes for kd tree


		// initialize indices as {0, 1, 2, ..., faces.size()-1}
		std::vector<int> indices; 
		for (unsigned i = 0; i < this->faces.size(); i++) {
			indices.push_back(i);
			// compute AABB for the triangle
			this->faces[i].computeAABB();

		}

		// define the root node of the KD-tree
		m_rootNode = std::unique_ptr<KDTreeNode>(new KDTreeNode);

		// build the KD-tree and calculate the time it takes to build the tree
		using std::chrono::high_resolution_clock;

		auto startTime = high_resolution_clock::now();
		buildTree(m_rootNode, indices, 0);
		auto endTime = high_resolution_clock::now();
		auto elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
		std::cout << "KD-tree build time: " << elapsedTime.count() << " milliseconds" << std::endl;

	}
}

/***
 * Builds the KD-tree using variable node, indices that belong to the node and tree depth
 *
 * @param node
 * @param indices
 * @param depth
*/
void Model::buildTree(std::unique_ptr<KDTreeNode>& node, const std::vector<int>& indices, int depth){

	// stop criterion met
	if (indices.size() <= KDTreeNode::MAX_TRIANGLES_PER_LEAF || depth == 20) {
		// assign triangles to the node
		node->m_indices = indices;
		return;
	}

	int axis = depth % 3;

	std::vector<int> leftList;
	std::vector<int> rightList; 
	
	// find AABB
	Vector3 min, max;
	findAABB(min, max, indices);
	node->m_aabb.setBounds(min, max);

	float aabbArea = node->m_aabb.area();

	float bestCostOfSplitting = 0;

	// spatial median
	//float splitPosition = (max[axis] + min[axis]) / 2.0f;

	float splitPosition = KDTreeNode::findOptimalSplitPosition(bestCostOfSplitting, axis, indices, this->faces, node, aabbArea);

	// determine if it is better to continue deeper in the tree or to stop here (leaf node)
	if (bestCostOfSplitting > 80.0f * indices.size()){
		node->m_indices = indices;
	//	std::cout << "terminate cell " << indices.size() << std::endl;
		return;
	}

	node->splitPosition = splitPosition;
	node->axis = axis;

	// iterate through the primitives
	for (int index : indices){
		Triangle triangle = this->faces[index];
		AABB aabb = triangle.getAABB();

		int result = aabb.intersects(axis, splitPosition);

		if (result < 0){
			// triangle belongs to the left child
			leftList.push_back(index);
		} else if(result > 0) {
			// triangle belongs to the right child
			rightList.push_back(index);	
		} else {
			// triangle belongs to the both sides
			node->m_indices.push_back(index);
		}

	}
	
	// go deeper in the tree
	node->m_leftChild = std::unique_ptr<KDTreeNode>(new KDTreeNode);
	node->m_rightChild = std::unique_ptr<KDTreeNode>(new KDTreeNode);
	
	buildTree(node->m_leftChild, leftList, depth+1);
	buildTree(node->m_rightChild, rightList, depth+1);
}

void Model::findAABB(Vector3& min, Vector3& max, const std::vector<int>& primitiveIndices) {

	for (int i = 0; i < 3; i++){
		max[i] = -std::numeric_limits<float>::max();
		min[i] = std::numeric_limits<float>::max();
	}

	float value = 0;

	for (int index : primitiveIndices) {
		// find max values
		value = this->faces[index].getHighestExtreme(0);
		if (value > max[0]){
			max[0] = value;
		}
		value = this->faces[index].getHighestExtreme(1);
		if (value > max[1]){
			max[1] = value;
		}
		value = this->faces[index].getHighestExtreme(2);
		if (value > max[2]){
			max[2] = value;
		}
		// find min values
		value = this->faces[index].getLowestExtreme(0);
		if (value < min[0]){
			min[0] = value;
		}
		value = this->faces[index].getLowestExtreme(1);
		if (value < min[1]){
			min[1] = value;
		}
		value = this->faces[index].getLowestExtreme(2);
		if (value < min[2]){
			min[2] = value;
		}
	}

}

const Vector3& Model::getMaxBounds() const {
    return this->maxBounds;
}


const Vector3& Model::getMinBounds() const {
    return this->minBounds;
}


Vector3 Model::getBoundingBoxCenter() const {
    return (this->minBounds + this->maxBounds) / 2;
}


unsigned Model::getNumberOfFaces() const {
    return this->faces.size();
}


Triangle& Model::getFace(unsigned index) {
    assert(index < this->faces.size());
    return this->faces[index];
}


bool Model::useKDTree() const {
    return this->searchKDTree;
}


void Model::useKDTree(bool use) {
    this->searchKDTree = use;
}


bool Model::backfaceCulling() const {
    return this->backfaceCull;
}


void Model::backfaceCulling(bool backfaceCulling) {
    this->backfaceCull = backfaceCulling;
}


bool Model::frontfaceCulling() const {
    return this->frontfaceCull;
}


void Model::frontfaceCulling(bool frontfaceCulling) {
    this->frontfaceCull = frontfaceCulling;
}


std::string Model::toString(unsigned indent, bool extraInfo) const {
    std::ostringstream res;
    std::string tabs = "";
    for(unsigned i = 0; i < indent; i++)
    {
        tabs += '\t';
    }
    res << tabs << "Model " << this->filename << std::endl;
    tabs += '\t';
    res << tabs << this->faces.size() << " faces, " << this->vertexes.size() << " vertexes" << 
            std::endl;
    res << tabs << "Min bounds: " << this->minBounds.toString() << std::endl;
    res << tabs << "Max bounds: " << this->maxBounds.toString();
    if(extraInfo) {
        res << std::endl << tabs << "Vertex data: " << std::endl;
        for(unsigned i = 0; i < this->vertexes.size(); ++i) {
            res << tabs << "\t" << i << ": " << this->vertexes[i].toString() << std::endl;
        }
        res << tabs << "Face data: ";
        for(unsigned i = 0; i < this->vertexes.size(); ++i) {
            res << std::endl << tabs << "\t" << i << ": " << this->faces[i].toString();
        }
    }
    return res.str();
}


bool Model::getIntersection(Ray& ray) const {

    if(this->searchKDTree) {
        // Get intersection using KD Tree
		bool found = m_rootNode->traverseTree(ray, this->faces);
		return found;
    }
    bool somethingFound = false;
    for(unsigned i = 0; i < this->faces.size(); ++i) {
        const Triangle& tri = this->faces[i];
        if(ray.startingPoint != &tri && tri.intersects(ray) == 1) {
            /* We have a hit */
            somethingFound = true;
            if(ray.intersectionType == Ray::ANY) {
                break;
            }
        }
    }
    /* Maybe we found something, maybe not */
    return somethingFound;
}


