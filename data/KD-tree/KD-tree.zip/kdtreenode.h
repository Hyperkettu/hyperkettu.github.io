#ifndef _KDTREENODE_H
#define _KDTREENODE_H

#include <memory>

#include "stdafx.h"
#include "ray.h"
#include "AABB.h"

// define a kd tree node
struct KDTreeNode {

	const static int MAX_TRIANGLES_PER_LEAF = 3; ///< constant determining the max number of triangles in a leaf node

	// define a Sweep Event
	struct SweepEvent {

		enum Event {
			TRIANGLE_START,
			TRIANGLE_END
		};

		int triIndex; ///< index of the triangle in the faces array
		Event type; ///< type of the event, start or end triangle
		float splitPosition; /// position of the split plane along an axis

	};

	/**
	 * Default constructor
	 */
	KDTreeNode() : m_leftChild(nullptr), m_rightChild(nullptr) {};

	/**
	 * Starts to traverse the KD-tree and to find an intersection between
	 * the ray and a triangle. Starts with a basic AABB-ray intersection test
	 * determining whether the ray hits the AABB of the model
	 * 
	 * @param ray
	 * @param faces, the triangle list
	 * @return true if found an intersection between a triangle and ray, false otherwise
	 */
	bool traverseTree(Ray& ray, const AlignedArray<Triangle>& faces);

	/**
	 * Traverses the nodes of the KD-tree trying to find an intersection between the ray
	 * and the faces between the interval [tmin, tmax] and writes the found value to thit variable
	 * 
	 * @param ray
	 * @param faces
	 * @param tmin
	 * @param tmax
	 * @param thit
	 * @return -1 if shadow ray, 0 otherwise
	 */
	int traverseNode(Ray& ray, const AlignedArray<Triangle>& faces, float tmin, float tmax, float& thit);

	/***
	* Finds the optimal split position
	*
	* @param axis
	* @param primitives, index -> triangle list
	* @param faces, the triangles
	* @param kdtree node
	* @param aabbArea
	* @return the optimal split position on the axis
	*/
	static float findOptimalSplitPosition(float& bestCostOfSplitting, unsigned axis, const std::vector<int>& primitives, const AlignedArray<Triangle>& faces, std::unique_ptr<KDTreeNode>& node, float aabbArea);

	/***
	* Calculate the cost on the split plane position, uses constants costTraverse = 1, costIntersect = 80
	* based on the reference Markus Kettunen Pro Gradu - Rendering Equation.
	*
	* Uses following Surface Area Heuristic:
	* costTraverse + costIntersect * (leftArea * leftCount + rightArea * rightCount) / aabbArea (of the node)
	*
	* @param splitPosition
	* @param node 
	* @param axis
	* @param leftCount
	* @param rightCount
	* @param aabbArea
	* @return total cost 
	*/
	static float calculateCost(float splitPosition, std::unique_ptr<KDTreeNode>& node, unsigned axis, size_t leftCount, size_t rightCount, float aabbArea);

	AABB m_aabb; ///< axis aligned bounding box of the kd tree node
	float splitPosition; // position of the split plane in an axis
	int axis; ///< X,Y or Z (0, 1 or 2), the axis that split plane splits against
	std::unique_ptr<KDTreeNode> m_leftChild; ///< left child in the binary tree
	std::unique_ptr<KDTreeNode> m_rightChild; ///< right child in the binary tree
	std::vector<int> m_indices; ///< indices to triangles in this node
};

#endif