#ifndef _MODEL_H
#define	_MODEL_H

#include <memory>

#include "stdafx.h"
#include "ply_reader.h"
#include "ray.h"
#include "AABB.h"
#include "kdtreenode.h"

class Model {
private:
	/* Maximum and minimum dimensions of model */
	Vector3 maxBounds;
	Vector3 minBounds;
	/* Filename is stored to give model a human-readable name */
	std::string filename;
	/* Structures for faces, vertexes and KD tree */
	AlignedArray<Triangle> faces;
	AlignedArray<Vector3> vertexes;
   // KD-tree declaration
	std::unique_ptr<KDTreeNode> m_rootNode;
	/* There's really no reason not to use KD tree, but ability to turn it's usage of has been left 
	 * here for debugging purposes. */
	bool searchKDTree;
	/* Depending on model you may want to backface cull or not. Frontface culling is not 
	 * available. */
	bool backfaceCull;
	bool frontfaceCull;

	/**
	 * Builds a KD-tree starting from the node parameter, indices determine the faces that are inside 
	 * this node and depth tells the depth in the tree
	 *
	 * @param node
	 * @param indices
	 * @param depth
	 */
	void buildTree(std::unique_ptr<KDTreeNode>& node, const std::vector<int>& indices, int depth);

	/**
	 * Finds an AABB for faces determined by the primitivesIndices index list and writes them to min and max vectors
	 *
	 * @param min
	 * @param max
	 * @param primitiveIndices
	 */
	void findAABB(Vector3& min, Vector3& max, const std::vector<int>& primitiveIndices);

public:
	/* Default constructor model() doesn't really work. TODO: separate model loading to different 
	 * public method. */
	Model(const std::string modelFile = "", bool searchKDTree = true);
	Model(const Model& orig) { throw; };
	Model& operator=(const Model& orig) { throw; };
	//~Model();
	/* These methods return maxes, mins and center of model's bounding box */
	const Vector3& getMaxBounds() const;
	const Vector3& getMinBounds() const;
	Vector3 getBoundingBoxCenter() const;
	unsigned getNumberOfFaces() const;
	Triangle& getFace(unsigned index);
	/* Getter and setter for use_kd_tree feature */
	bool useKDTree() const;
	void useKDTree(bool use);
	/* Getter and setter for backface culling */
	bool backfaceCulling() const;
	void backfaceCulling(bool backfaceCulling);
	/* Getter and setter for frontface culling */
	bool frontfaceCulling() const;
	void frontfaceCulling(bool frontfaceCulling);
	std::string toString(unsigned indent = 0, bool extraInfo = false) const;
	/* Calculates whether the ray intersects with any of triangles on the tree. Obeys backface 
	 * culling and other parameters set in ray object. If suitable triangle is found, true is 
	 * returned, otherwise false. */
	bool getIntersection(Ray& ray) const;
	/* Tests if kd_tree and brute force return same results */
	bool getIntersectionTest(Ray& ray) const;
};

#endif /* _MODEL_H */