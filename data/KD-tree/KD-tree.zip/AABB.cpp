
#include "stdafx.h"
#include <utility>

#include "AABB.h"
#include "ray.h"


float AABB::area() {
	Vector3 dimensions = bbMax - bbMin;
	float deltaX = dimensions[0];
	float deltaY = dimensions[1];
	float deltaZ = dimensions[2];
	return 2.0f * (deltaX * deltaY + deltaX * deltaZ + deltaY * deltaZ);
}

float AABB::leftArea(unsigned axis, float splitPosition) {

	// X axis
	if (axis == 0){

		float deltaX = splitPosition - bbMin[0];
		float deltaY = bbMax[1] - bbMin[1];
		float deltaZ = bbMax[2] - bbMin[2];

		return 2.0f * (deltaX * deltaY + deltaX * deltaZ + deltaY * deltaZ);

	}
	else if (axis == 1) { // Y axis

		float deltaX = bbMax[0] - bbMin[0];
		float deltaY = splitPosition - bbMin[1];
		float deltaZ = bbMax[2] - bbMin[2];

		return 2.0f * (deltaX * deltaY + deltaX * deltaZ + deltaY * deltaZ);

	}
	else if (axis == 2) { // Z axis

		float deltaX = bbMax[0] - bbMin[0];
		float deltaY = bbMax[1] - bbMin[1];
		float deltaZ = splitPosition - bbMin[2];

		return 2.0f * (deltaX * deltaY + deltaX * deltaZ + deltaY * deltaZ);
	}

	return 0;
}

float AABB::rightArea(unsigned axis, float splitPosition) {

	// X axis
	if (axis == 0){

		float deltaX = bbMax[0] - splitPosition;
		float deltaY = bbMax[1] - bbMin[1];
		float deltaZ = bbMax[2] - bbMin[2];

		return 2.0f * (deltaX * deltaY + deltaX * deltaZ + deltaY * deltaZ);

	}
	else if (axis == 1) { // Y axis

		float deltaX = bbMax[0] - bbMin[0];
		float deltaY = bbMax[1] - splitPosition;
		float deltaZ = bbMax[2] - bbMin[2];

		return 2.0f * (deltaX * deltaY + deltaX * deltaZ + deltaY * deltaZ);

	}
	else if (axis == 2) { // Z axis

		float deltaX = bbMax[0] - bbMin[0];
		float deltaY = bbMax[1] - bbMin[1];
		float deltaZ = bbMin[2] - splitPosition;

		return 2.0f * (deltaX * deltaY + deltaX * deltaZ + deltaY * deltaZ);
	}

	return 0;
}

std::pair<float, float> AABB::intersect(const Ray& ray) {
	
	Vector3 dir = ray.direction;
	Vector3 orig = ray.origin;

	float tMin[3];
	float tMax[3];

	for(int i = 0; i < 3; i++) {
		
		if(dir[i] == 0) {
			if(orig[i] < bbMin[i] || orig[i] > bbMax[i]){
				return std::make_pair(std::numeric_limits<float>::max(), 0);
			}
			tMax[i] = std::numeric_limits<float>::max();
			tMin[i] = -std::numeric_limits<float>::max();

		} else {
			
			tMin[i] = (bbMin[i] - orig[i])/dir[i];
			tMax[i] = (bbMax[i] - orig[i])/dir[i];

			if(tMin[i] > tMax[i]) {
				std::swap(tMin[i], tMax[i]);
			}
			
		}

	}

	// calculate the min of maxs and max of mins
	float maxOfMins = std::max(tMin[0], std::max(tMin[1], tMin[2]));
	float minOfMaxs = std::min(tMax[0], std::max(tMax[1], tMax[2]));

	return std::make_pair(maxOfMins, minOfMaxs);
}