#include "stdafx.h"
#include "kdtreenode.h"

bool KDTreeNode::traverseTree(Ray& ray, const AlignedArray<Triangle>& faces) {

	// find and interval where the ray intersects the AABB
	std::pair<float, float> t = this->m_aabb.intersect(ray);
	t.first = std::max(0.0f, t.first);

	// if the box is behind there is no intersection
	if (t.first >= t.second) {
		return false;
	}

	// traverse the tree for intersections
	float thit = std::numeric_limits<float>::max();
	ray.bestDistanceSq = std::numeric_limits<float>::max();
	traverseNode(ray, faces, t.first, t.second, thit);
	// if we have a closer hit than the AABB of the model, return true
	return thit <= t.second;
}

int KDTreeNode::traverseNode(Ray& ray, const AlignedArray<Triangle>& faces, float tmin, float tmax, float& thit) {

	// if the current node has triangles
	if (!m_indices.empty()){
		bool hit = false;
		// iterate through the triangles
		for (int index : m_indices) {
			const Triangle& triangle = faces[index];
			if (ray.startingPoint != &triangle && triangle.intersects(ray) == 1) {
				hit = true;
				if(ray.intersectionType == Ray::ANY) {
					//early exit for shadowrays
					return -1;
				}
			}
		}

		if (hit)
			thit = std::sqrt(ray.bestDistanceSq / ray.direction.lengthSquared());
	}

	// if node has children
	if (this->m_leftChild && this->m_rightChild) {

		float t;

		// find the t for hit to the split plane
		if (ray.direction[axis] != 0) {
			t = (splitPosition - ray.origin[axis]) / ray.direction[axis];
		}
		else {
			t = std::numeric_limits<float>::max();
		}
		// find the position of the hit in the axis
		float position = ray.origin[axis] + ray.direction[axis] * tmin;

		int shadowRaysReturn = 0;

		// determine the order in which the children are traversed
		if (position < splitPosition) {
			if (tmin <= t && t <= tmax) {
				shadowRaysReturn = m_leftChild->traverseNode(ray, faces, tmin, t, thit);

				// early exit for shadow rays
				if (shadowRaysReturn == -1){
					return -1;
				}

				if (t <= thit) {
					shadowRaysReturn = m_rightChild->traverseNode(ray, faces, t, tmax, thit);

					// early exit for shadow rays
					if (shadowRaysReturn == -1){
						return -1;
					}
				}
			}
			else {
				shadowRaysReturn = m_leftChild->traverseNode(ray, faces, tmin, tmax, thit);
				// early exit for shadow rays
				if (shadowRaysReturn == -1) {
					return -1;
				}
			}
		}
		else { // position >= splitPosition
			if (tmin <= t && t <= tmax) {
				shadowRaysReturn = m_rightChild->traverseNode(ray, faces, tmin, t, thit);

				// early exit for shadow rays
				if (shadowRaysReturn == -1) {
					return -1;
				}

				if (t <= thit) {
					shadowRaysReturn = m_leftChild->traverseNode(ray, faces, t, tmax, thit);

					// early exit for shadow rays
					if (shadowRaysReturn == -1) {
						return -1;
					}
				}
			}
			else {
				shadowRaysReturn =  m_rightChild->traverseNode(ray, faces, tmin, tmax, thit);

				// early exit for shadow rays
				if (shadowRaysReturn == -1){
					return -1;
				}
			}
		}
	}
}

float KDTreeNode::findOptimalSplitPosition(float& bestCostOfSplitting, unsigned axis, const std::vector<int>& primitives, const AlignedArray<Triangle>& faces, std::unique_ptr<KDTreeNode>& node, float aabbArea){

	int countLeft = 0, countRight = primitives.size();
	std::vector<SweepEvent> events;

	// define the sweep events based on triangle data
	for (int index : primitives) {

		const Triangle& tri = faces[index];
		float start = tri.getLowestExtreme(axis);
		float end = tri.getHighestExtreme(axis);

		SweepEvent se = { index, SweepEvent::TRIANGLE_START, start };
		SweepEvent se2 = { index, SweepEvent::TRIANGLE_END, end };

		events.emplace_back(se);
		events.emplace_back(se2);
	}
	// sort the events to an ascdending order based on the split position along an axis
	std::sort(events.begin(), events.end(), [](const SweepEvent& first, const SweepEvent& second) {

		return first.splitPosition < second.splitPosition;
	});


	float bestPosition = -1.0f;
	float bestCost = std::numeric_limits<float>::max();
	float cost = 0;

	// iterate through all primitives
	for (SweepEvent& e : events) {

		if (e.type == SweepEvent::TRIANGLE_START){
			cost = calculateCost(e.splitPosition, node, axis, countLeft, countRight, aabbArea);
			countLeft++;
		}
		else { // TRIANGLE_END
			countRight--;
			cost = calculateCost(e.splitPosition, node, axis, countLeft, countRight, aabbArea);
		}
		// if we found a smaller cost, update thge best cost and best split position
		if (cost < bestCost) {
			bestCost = cost;
			bestPosition = e.splitPosition;
		}
	}

	bestCostOfSplitting = bestCost;
	return bestPosition;
}

float KDTreeNode::calculateCost(float splitPosition, std::unique_ptr<KDTreeNode>& node, unsigned axis, size_t leftCount, size_t rightCount, float aabbArea){

	float costTraverse = 1.0f;
	float costIntersect = 80.0f;
	float leftArea = node->m_aabb.leftArea(axis, splitPosition);
	float rightArea = node->m_aabb.rightArea(axis, splitPosition);
	return costTraverse + costIntersect * (leftArea * leftCount + rightArea * rightCount) / aabbArea;
}