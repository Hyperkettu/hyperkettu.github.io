/*
 * graph.hpp
 *
 *  Created on: 7.11.2010
 *      Author: Olli Kettunen
 */

#ifndef GRAPH_HPP_
#define GRAPH_HPP_

#include <set>
#include <list>
#include <algorithm>

// describes connection between two routers
struct Edge {

	Edge(int first, int second, size_t dist = 1) :
		i(first, second), dist(dist) {
	}
	// operators for std::set container, requires that these are implemented
	friend bool operator==(const Edge&, const Edge&);
	friend bool operator<(const Edge&, const Edge&);

	std::pair<int, int> i;
	size_t dist;
};

bool operator==(const Edge& left, const Edge& right) {
	return (left.i == right.i) && left.dist == right.dist;
}

bool operator<(const Edge& f, const Edge& s) {
	return f.i < s.i;
}

// graph describes router network, where routers are as nodes
class Graph {

public:
	Graph() {
	}

	~Graph() {
	}

	// returns routers in the network
	std::list<int> getRouters() const {

		std::list<int> l;
		std::set<Edge>::const_iterator iter;

		for (iter = edges.begin(); iter != edges.end(); iter++) {
			l.push_back(iter->i.first);
			l.push_back(iter->i.second);
		}

		l.sort();
		l.unique();

		return l;
	}

	// return list of interfaces from this router
	std::set<Edge> getNeighbours(int v) const {

		std::set<Edge> s;
		std::set<Edge>::const_iterator iter;

		for (iter = edges.begin(); iter != edges.end(); iter++) {
			if (iter->i.first == v)
				s.insert(*iter);
		}
		return s;
	}

	// returns edges for this graph
	std::set<Edge> getEdges() const {
		return edges;
	}

	// adds an edge to the graph, add both n -> m and m -> n directions
	void addEdge(const Edge &edge) {
		removeEdge(edge);
		edges.insert(edge);
		edges.insert(Edge(edge.i.second, edge.i.first, edge.dist));

	}

	// removes edge from graph, note both m->n and n->m
	void removeEdge(const Edge &edge) {
		edges.erase(edge);
		edges.erase(Edge(edge.i.second, edge.i.first));
	}

private:
	std::set<Edge> edges;
};

// prints graph for testing purpose
std::ostream& operator<<(std::ostream &os, const Graph &g) {

	std::list<int> routers = g.getRouters();
	std::list<int>::const_iterator iter;
	std::set<Edge>::const_iterator e;

	for (iter = routers.begin(); iter != routers.end(); iter++) {

		std::set<Edge> neig = g.getNeighbours(*iter);

		if (neig.size() == 0)
			continue;

		if (iter != routers.begin())
			os << std::endl;

		os << *iter << " :";

		for (e = neig.begin(); e != neig.end(); e++) {
			os << " " << e->i.second << "(" << e->dist << ")";
		}
	}
	return os;
}

#endif /* GRAPH_HPP_ */
