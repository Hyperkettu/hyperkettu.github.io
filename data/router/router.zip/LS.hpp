/*
 * LS.hpp
 *	Implementation for link status protocol
 *  Created on: Nov 4, 2010
 *      Author: Olli Kettunen
 */

#include "essentials.hpp"
#include "graph.hpp"

#ifndef LS_HPP_
#define LS_HPP_

class LS {

public:
	LS(std::string &user): user(user) { // initializes connection on creation
		initConnection();
	}

	~LS() { // closes connection and frees struct
		close(sockfd);
		freeaddrinfo(res);
	}

	// initializes connection to server
	void initConnection() {

		std::cout << "Initializing connection to server" << std::endl;
		user.push_back('\n');

		// init structs
		memset(&s, 0, sizeof(s));
		s.ai_family = AF_UNSPEC; // IPv4 or IPv6
		s.ai_socktype = SOCK_STREAM; // stream socket

		getaddrinfo("hiljainen.cs.hut.fi", "11042", &s, &res);

		sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);

		connect(sockfd, res->ai_addr, res->ai_addrlen);
	}

	// authenticates user to server
	void authenticate() {

		std::cout << "Authenticating..." << std::endl;

		while (true) { // resend while we manage to authenticate

			char buf[20] = { '\0' };
			send(sockfd, user.c_str(), user.size(), 0);
			recv(sockfd, buf, 20, 0);
			std::string buffer(buf);

			if (buffer.substr(0, 7) == "AUTH_OK")
				break;
		}

		std::cout << "Authentication succeeded" << std::endl;
	}

	// gets router neighbors with HELLO and ECHO messages
	void getNeighbors() {

		std::cout << "Sending HELLO message" << std::endl;

		//HELLO
		std::string hello = "HELLO\n";
		send(sockfd, hello.c_str(), hello.size(), 0);

		while (true) { // parse HELLO messages until NOMORENEIGHBORS

			char buf[40] = { '\0' };
			char *pch;
			recv(sockfd, buf, 39, MSG_PEEK);

			pch = strtok(buf, "\n");

			if (parseHello(pch)) {
				recv(sockfd, buf, strlen(pch) + 1, 0);
				break;
			}

			recv(sockfd, buf, strlen(pch) + 1, 0);
		}

		// parse ECHO
		std::cout << "Sending ECHO message" << std::endl;
		std::string echo = "ECHO\n";
		send(sockfd, echo.c_str(), echo.size(), 0);

		// add distances and neighbors to the graph
		for (size_t i = 0; i < neighbors.size(); i++) {

			char buf[40] = { '\0' };
			char *pch;
			recv(sockfd, buf, 39, MSG_PEEK);

			// parse message
			pch = strtok(buf, "\n");
			int n = -1, d = -1;
			std::stringstream ss(pch);
			ss.ignore(11, ' ');
			ss >> n;
			ss.ignore(2, ' ');
			ss >> d;
			g.addEdge(Edge(1, n, d));

			recv(sockfd, buf, strlen(pch) + 1, 0);
		}

		std::cout << "Neighbors detected" << std::endl;
	}

	// parses given hello char* returns 0 on success
	int parseHello(const char* buf) {

		std::string buffer(buf);

		if (buffer.substr(0, 5) != "HELLO") {
			if (buffer.substr(0, 18) == "NOMORENEIGHBORS, 0") {
				return 1;
			}
		}

		int n = -1, i = -1;

		// parse HELLO
		std::stringstream ss(buffer);
		ss.ignore(7, ' ');
		ss >> n;
		ss.ignore(2, ' ');
		ss >> i;
		neighbors[n] = i;
		return 0;
	}

	// this function forms graph according to data received from server
	// uses dijkstra to construct shortest paths
	void constructPaths() {

		std::cout << "Sending INFORM message" << std::endl;

		std::string inform = "INFORM\n";

		send(sockfd, inform.c_str(), inform.size(), 0);

		int i = 1;

		// receive messages until shutdown
		while (i != 0) {

			char buf[50] = { '\0' };
			char *pch;
			i = recv(sockfd, buf, 49, MSG_PEEK);
			pch = strtok(buf, "\n");

			if (pch == NULL)
				break;

			std::string buffer(pch);

			// we have and INFORM message
			if (buffer.substr(0, 6) == "INFORM") {

				int nr = -1, nn = -1, d = -1;
				// parse message
				std::stringstream ss(buffer);
				ss.ignore(8, ' ');
				ss >> nr;
				ss.ignore(2, ' ');
				ss >> nn;
				ss.ignore(2, ' ');
				ss >> d;

				// if parsing succeeded
				if (nr != -1 && nn != -1 && d != -1) {
					g.addEdge(Edge(nr, nn, d));
					paths = dijkstra(g, 1, previous);
				}
			}

			i = recv(sockfd, buf, strlen(pch) + 1, 0);
		}
	}

	// submits table to server
	void submitTable() {

		struct addrinfo spe, *re;
		int sock;

		// load address structs
		memset(&spe, 0, sizeof(spe));
		spe.ai_family = AF_UNSPEC; // IPv4 or IPv6
		spe.ai_socktype = SOCK_STREAM; // Stream

		getaddrinfo("hiljainen.cs.hut.fi", "11043", &spe, &re);

		// make a socket
		sock = socket(re->ai_family, re->ai_socktype, re->ai_protocol);

		// connect TCP
		connect(sock, re->ai_addr, re->ai_addrlen);

		// table formatting for returning
		std::stringstream ss;
		std::stringstream se;

		// add first node
		ss << 1 << "," << 0 << "," << 0 << ";";
		se << "Shortest paths, name, distance (interface): " << std::endl;
		se << 1 << " " << 0 << " (" << 0 << ")" << std::endl;

		std::map<int, size_t>::const_iterator iter;

		for (iter = paths.begin(); iter != paths.end(); iter++) {

			if (iter->first == 1)
				continue;

			std::list<int> ids;
			getInterfaces(iter->first, ids);
			ids.sort();
			ids.unique();

			for (std::list<int>::const_iterator it = ids.begin(); it
					!= ids.end(); it++) {
				ss << iter->first << ",";
				ss << iter->second << ",";
				ss << *it << ";";

				// for print
				se << iter->first << " " << iter->second << " (" << *it << ")" << std::endl;
			}
		}

		ss << std::endl;

		// authenticate:
		while (true) {
			// sleep for one second and resend if no AUTH_OK received

			char buf[30] = { '\0' };
			send(sock, user.c_str(), user.size(), 0);
			recv(sock, buf, 30, 0);
			std::string buffer(buf);

			// if authentication succeeded do not resend
			if (buffer.substr(0, 7) == "AUTH_OK")
				break;

			sleep(1);
		}

		// print table in readable form
		std::cout << se.str();

		// send table and receive success
		std::cout << "Sending table" << std::endl;

		send(sock, ss.str().c_str(), ss.str().size(), 0);
		char buff[500] = { '\0' };
		recv(sock, buff, 499, 0);
		std::cout << buff << std::endl;
		std::cout << "Table sent" << std::endl;

		close(sock);
		freeaddrinfo(re);
	}

	// gets Interfaces for given router, may contains duplicates
	// list ids must be sorted and uniqued afterwards
	void getInterfaces(int name, std::list<int> &ids) {

		if (name == 1)
			return;

		std::multimap<int, int>::const_iterator iter;
		std::pair<std::multimap<int, int>::const_iterator, std::multimap<int,
				int>::const_iterator> it = previous.equal_range(name);

		// all previous routers
		for (iter = it.first; iter != it.second; iter++) {

			if (iter->second == 1)
				ids.push_back(neighbors[iter->first]);

			getInterfaces(iter->second, ids);
		}
	}

private:
	int sockfd;
	struct addrinfo s, *res;
	Graph g;
	std::string user;
	std::map<int, int> neighbors; //neighbor to interface
	std::map<int, size_t> paths; // path lenghts for routers
	std::multimap<int, int> previous; // contains previous router on the shortest path to router
};

#endif /* LS_HPP_ */
