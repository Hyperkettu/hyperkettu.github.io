#include "DV.hpp"
#include "LS.hpp"
/*
 * main.cpp
 *
 *  Created on: Nov 2, 2010
 *      Author: Olli Kettunen
 */

int main(int argc, char* argv[]) {

	if (argc == 2) {

		std::string usr(argv[1]);

		// connect to hiljainen.cs.hut.fi with DV protocol

		 DV dv(usr);
		 dv.authenticate();
		 dv.collectData();
		 dv.submitTable();

		// connect to hiljainen.cs.hut.fi with LS protocol
		 /*
		 sleep(5);
		 
		LS ls(usr);
		ls.authenticate();
		ls.getNeighbors();
		ls.constructPaths();
		ls.submitTable();*/
		return 0;
	}
	return 1;
}
