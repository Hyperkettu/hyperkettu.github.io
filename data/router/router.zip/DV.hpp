/*
 * DV.hpp
 *	Implementation for distance vector protocol
 *  Created on: Nov 3, 2010
 *      Author: Olli Kettunen
 */
#include "essentials.hpp"
#include <vector>

#ifndef DV_HPP_
#define DV_HPP_

class DV {

public:
	DV(const std::string user) : user(user), limit(500) { // init connection to server on creation
		initConnection();
	}

	// free struct and close connection
	~DV() {
		freeaddrinfo(res);
		close(sockfd);
	}

	// initializes connection to server
	void initConnection() {

		std::cout << "Initializing connection to server" << std::endl;

		// load address structs
		memset(&spec, 0, sizeof(spec));
		spec.ai_family = AF_UNSPEC; // IPv4 or IPv6
		spec.ai_socktype = SOCK_DGRAM; // Datagram

		getaddrinfo("hiljainen.cs.hut.fi", "11041", &spec, &res);

		// make a socket
		sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
	}

	// authenticates user to server
	void authenticate() {

		std::cout << "Authenticating..." << std::endl;

		// authenticate:

		while(true) {
			// sleep for one second and resend if no AUTH_OK received

			char buf[20] = { '\0' };
			sendi(user);
			rec(buf, 20);
			std::string buffer(buf);

			// if authentication succeeded do not resend
			if(buffer.substr(0,7) == "AUTH_OK"){
				sec = lexical_cast<int> (std::string(buffer.begin() + 8, buffer.end()));
				break;
			}

			sleep(1);
		}

		// ack AUTH_OK, sequence +1
		sec++;
		ack();
		std::cout << "Authentication succeeded" << std::endl;
	}

	// acks given data
	void ack() {
		std::stringstream ss;
		ss << "ACK " << sec;
		sendi(ss.str());
	}

	// collects data from routers
	void collectData() {

		std::cout << "Collecting data from neighbour routers" << std::endl;

		int i = -1, n = -1, d = -1, psec = -1, count = 0;
		bool mod = true;

		while (true) {

			// no new data to table
			if (!mod)
				count++;
			else
				count = 0;

			// if table hasn't been modified for over limit packets, stop receiving routing data
			if (!mod && count > limit)
				break;

			// receive data
			char buff[50] = { '\0' };
			rec(buff, 50);

			// parse router data
			std::string b(buff);
			std::stringstream ss(b);
			ss.ignore(1, '[');
			ss >> i;
			ss.ignore(2, ' ');
			ss >> n;
			ss.ignore(2, ' ');
			ss >> d;
			ss.ignore(2, ' ');
			ss >> psec;

			// if values are still as initialized -> wrong type packet
			if(i == -1 || n == -1 || d == -1 || psec == -1){
				ack();
				count--; // wrong packet do not increase count
				continue;
			}

			// we didn't get what we wanted
			if (psec != sec) {
				ack();
				count--; // wpdnic
				continue;
			}

			// right packet

			// add new router if empty table
			if (routes.empty()) {
				mod = true;
				Router temp = { n, i, std::min(d + 1, 16) };
				routes.push_back(temp);
				sec++;
				ack();
				continue;
			}

			// search for router
			std::vector<Router>::iterator iter;

			for (iter = routes.begin(); iter != routes.end(); iter++) {
				// if router already in table
				if (iter->name == n)
					break;
			}

			// router found
			if (iter != routes.end()) {
				mod = false;
				// if found shorter path
				if (iter->dist > d + 1) {
					// update routing data
					iter->dist = std::min(d + 1, 16);
					iter->i = i;
					mod = true;
				}
				sec++;
				ack();
				continue;

			} else { // router not found

				// add new router and add sec
				Router temp = { n, i, std::min(d + 1, 16) };
				routes.push_back(temp);
				sec++;
				ack();
				continue;
			}
		}
		std::cout << "Enough data received" << std::endl;
	}

	// fast function for net sending
	void sendi(const std::string& str) {
		sendto(sockfd, str.c_str(), str.size(), 0, res->ai_addr,
				res->ai_addrlen);
	}

	// fast function for net receiving
	void rec(char buf[], int size) {
		recvfrom(sockfd, buf, size - 1, 0, NULL, NULL);
	}

	// submits table to server
	void submitTable() {

		std::cout << "Submitting table" << std::endl;

		struct addrinfo spe, *re;
		int sock;

		// load address structs
		memset(&spe, 0, sizeof(spe));
		spe.ai_family = AF_UNSPEC; // IPv4 or IPv6
		spe.ai_socktype = SOCK_STREAM; // Stream

		getaddrinfo("hiljainen.cs.hut.fi", "11043", &spe, &re);

		// make a socket
		sock = socket(re->ai_family, re->ai_socktype, re->ai_protocol);

		// connect TCP
		connect(sock, re->ai_addr, re->ai_addrlen);

		// authenticate
		user.push_back('\n');

		while(true) {
			// sleep for one second and resend if no AUTH_OK received

			char buf[30] = { '\0' };
			send(sock, user.c_str(), user.size(), 0);
			recv(sock, buf, 30, 0);
			std::string buffer(buf);

			// if authentication succeeded do not resend
			if(buffer.substr(0,7) == "AUTH_OK")
				break;

			sleep(1);
		}

		// table formatting for returning
		std::stringstream ss;
		std::stringstream se;
		se << "Shortest paths, name, distance, (interface):" << std::endl;
		se << 1 << " " << 0 << " (" << 0 << ")" << std::endl;

		std::vector<Router>::iterator iter;

		for (iter = routes.begin(); iter != routes.end(); iter++) {
			if(iter->name == 1){
				iter->dist = 0;
			}
			ss << iter->name << "," << iter->dist << "," << iter->i << ";";
			se << iter->name << " " << iter->dist << " (" << iter->i << ")" << std::endl;
		}
		ss << std::endl;

		// print table before sending it
		std::cout << se.str();

		// send table and receive success
		send(sock, ss.str().c_str(), ss.str().size(), 0);
		char buff[500] = {'\0'};
		recv(sock, buff, 500, 0);
		std::cout << buff;

		std::cout << "Table sent" << std::endl;

		close(sock);
		freeaddrinfo(re);
	}

private:
	std::vector<Router> routes; // list of routers this router knows
	std::string user;
	int sockfd;
	struct addrinfo spec, *res;
	int sec; // secquence number
	int limit; // limit for packet count that doesn't modify table, data collecting is stopped if limit approached

};

#endif /* DV_HPP_ */
