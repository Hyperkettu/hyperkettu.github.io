/*
 * essentials.hpp
 *
 *  Created on: Nov 3, 2010
 *      Author: Olli Kettunen
 */

#ifndef ESSENTIALS_HPP_
#define ESSENTIALS_HPP_

#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

#include <iostream>
#include <string>
#include <cstring>
#include <cerrno>
#include <cstdlib>
#include <sstream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>
#include <map>
#include <algorithm>

#include "graph.hpp"

// router struct used by distance vector protocol
struct Router {

	int name;
	int i;
	int dist;
};

namespace {

// function for casting source type S to type T
template<typename T, typename S>
T lexical_cast(const S& source) {
	T temp;
	std::stringstream ss;
	ss << source;
	ss >> temp;
	if (!ss)
		throw std::bad_cast();
	return temp;
}

// implementation for dijkstra algorithm
// calculates the shortest paths from given graph for given source router
std::map<int, size_t> dijkstra(const Graph &graph, const int source,
		std::multimap<int, int> &m) {
	// Infinity constant
	const size_t inf = -1;
	std::list<int> routers = graph.getRouters();
	std::map<int, size_t> distance;

	// init distance to all routers as infinite
	for (std::list<int>::iterator iter = routers.begin(); iter != routers.end(); iter++)
		distance[*iter] = inf;

	// shortest path predecessors for nodes
	std::multimap<int, int> previous;

	// source's distance from itself is zero
	distance[source] = 0;

	while (!routers.empty()) {
		// router with the shortest distance
		int min = routers.front();

		for (std::list<int>::const_iterator iter = routers.begin(); iter
				!= routers.end(); iter++)
			if (distance[min] > distance[*iter])
				min = *iter;

		// break if no further routers are accessible
		if (distance[min] == inf)
			break;

		// remove this router from the list and get neighbours
		routers.erase(std::find(routers.begin(), routers.end(), min));
		std::set<Edge> neighbours = graph.getNeighbours(min);

		for (std::set<Edge>::const_iterator iter = neighbours.begin(); iter
				!= neighbours.end(); iter++) {

			size_t d = distance[min] + iter->dist;

			// Update distance if found shorter
			if (d < distance[iter->i.second]) {

				//remove old longer routes if exist
				std::multimap<int, int>::iterator i = previous.find(
						iter->i.second);

				while (i != previous.end()) {
					previous.erase(i->first);
					i = previous.find(iter->i.second);
				}

				distance[iter->i.second] = d;
				previous.insert(std::pair<int, int>(iter->i.second, min));
			} else if (d == distance[iter->i.second]) {
				// equal distance added also
				previous.insert(std::pair<int, int>(iter->i.second, min));
			}
		}
	}
	m = previous;
	return distance;
}

}

#endif /* ESSENTIALS_HPP_ */
